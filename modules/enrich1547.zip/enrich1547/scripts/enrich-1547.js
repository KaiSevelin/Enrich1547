// modules/enrich-1547.js

/* -------------------------------------------- */
/*  1547 Enricher + Dice Dialog                 */
/* -------------------------------------------- */

const EN1547_DEBUG = false; // set true if you want extra console logs

Hooks.once("init", () => {
    // Add text enricher: @1547[1d6|2d4+1]{Label}
    CONFIG.TextEditor.enrichers.push({
        pattern: /@1547\[([^\]]+)\](?:\{([^}]+)\})?/g,
        enricher: async (match) => {
            const raw = match[1] ?? "";
            const label = match[2] ?? "@1547";

            const rolls = raw
                .split("|")
                .map((s) => s.trim())
                .filter(Boolean);

            const a = document.createElement("a");
            a.classList.add("enricher-1547");
            a.dataset.rolls = JSON.stringify(rolls);
            a.dataset.label = label;
            a.innerHTML = label;

            // Accessibility: treat it like a button
            a.setAttribute("role", "button");
            a.tabIndex = 0;

            return a;
        },
        replaceParent: false,
    });

    if (EN1547_DEBUG) console.log("enrich-1547 | init complete");
});

Hooks.once("ready", () => {
    // Click handler (capture-phase helps if something stops propagation)
    document.body.addEventListener(
        "click",
        async (ev) => {
            const el = ev.target?.closest?.("a.enricher-1547");
            if (!el) return;

            ev.preventDefault();
            ev.stopPropagation();

            let rolls;
            try {
                rolls = JSON.parse(el.dataset.rolls ?? "[]");
            } catch {
                rolls = [];
            }

            if (!Array.isArray(rolls) || rolls.length === 0) {
                return ui.notifications?.warn("No roll formulas found in @1547[...]");
            }

            const label = el.dataset.label ?? "@1547";
            await show1547RollDialog(rolls, label);
        },
        true
    );

    // Keyboard activation (Enter/Space)
    document.body.addEventListener(
        "keydown",
        async (ev) => {
            if (ev.key !== "Enter" && ev.key !== " ") return;
            const el = ev.target?.closest?.("a.enricher-1547");
            if (!el) return;
            el.click();
        },
        true
    );

    if (EN1547_DEBUG) {
        console.log("enrich-1547 | ready complete");
        ui?.notifications?.info("1547: script loaded (debug on)");
    }
});

/* -------------------------------------------- */
/*  Reliable button binding via renderDialog    */
/* -------------------------------------------- */

Hooks.on("renderDialog", (app, html) => {
    // Only target OUR dialog
    if (!html.find("form.dialog-1547").length) return;

    const updateRow = (idx, newTerm) => {
        const input = html.find(`input.dice-term[data-index="${idx}"]`)[0];
        if (input) input.value = newTerm;
    };

    // Bind + button
    html
        .find("button.dice-plus")
        .off("click.en1547")
        .on("click.en1547", (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            const row = ev.currentTarget.closest(".dice-row");
            const idx = Number(row?.dataset.index);
            const input = html.find(`input.dice-term[data-index="${idx}"]`)[0];
            const term = (input?.value ?? "").trim();

            const parsed = parseDiceTerm(term);
            if (!parsed) return;

            parsed.n = Math.max(0, parsed.n + 1);
            updateRow(idx, formatDiceTerm(parsed));

            if (EN1547_DEBUG) console.log("en1547 +", idx, term, "=>", formatDiceTerm(parsed));
        });

    // Bind - button
    html
        .find("button.dice-minus")
        .off("click.en1547")
        .on("click.en1547", (ev) => {
            ev.preventDefault();
            ev.stopPropagation();

            const row = ev.currentTarget.closest(".dice-row");
            const idx = Number(row?.dataset.index);
            const input = html.find(`input.dice-term[data-index="${idx}"]`)[0];
            const term = (input?.value ?? "").trim();

            const parsed = parseDiceTerm(term);
            if (!parsed) return;

            parsed.n = Math.max(0, parsed.n - 1);
            updateRow(idx, formatDiceTerm(parsed));

            if (EN1547_DEBUG) console.log("en1547 -", idx, term, "=>", formatDiceTerm(parsed));
        });
});

/* -------------------------------------------- */
/*  Dice parsing helpers                        */
/* -------------------------------------------- */

/**
 * Parse a dice term like:
 *  "2d4", "d20", "1d6+3", "2d6-1", "3d8kh2", etc.
 * We ONLY change the leading NdX count; everything after faces is preserved in `rest`.
 *
 * Returns { n, faces, rest } or null if not parseable.
 */
function parseDiceTerm(term) {
    const t = String(term ?? "").replace(/\s+/g, "");

    // [count] d [facesToken] [rest...]
    const m = t.match(/^(\d*)d([a-z0-9]+)(.*)$/i);
    if (!m) return null;

    // If count is omitted, treat as 1 (so "dv" works)
    const n = m[1] === "" ? 1 : Number(m[1]);
    const faces = m[2]; // string, e.g. "6", "dv", "s"
    const rest = m[3] ?? "";

    // Allow zero
    if (!Number.isFinite(n) || n < 0) return null;
    if (!faces) return null;

    return { n, faces, rest };
}

function formatDiceTerm({ n, faces, rest }) {
    // Always show the count explicitly (0dv, 1dv, 2dv...)
    return `${String(n)}d${faces}${rest ?? ""}`;
}

function buildCombinedFormula(terms) {
    // Combine into one roll (each term grouped)
    return terms.map((t) => `(${t})`).join(" + ");
}

/* -------------------------------------------- */
/*  Dialog + rolling                            */
/* -------------------------------------------- */

async function show1547RollDialog(formulas, titleLabel = "@1547") {
    const state = formulas.map((f) => {
        const parsed = parseDiceTerm(f);
        return {
            original: f,
            parsed,
            value: parsed ? formatDiceTerm(parsed) : f,
        };
    });

    const content = `
    <form class="dialog-1547">
      <p>Adjust dice then roll:</p>
      <div class="dice-list">
        ${state
            .map((s, i) => {
                const disabled = s.parsed ? "" : "disabled";
                return `
              <div class="dice-row" data-index="${i}">
                <button type="button" class="dice-minus" ${disabled} title="Remove one die">-</button>
                <input type="text" class="dice-term" value="${foundry.utils.escapeHTML(s.value)}" data-index="${i}" />
                <button type="button" class="dice-plus" ${disabled} title="Add one die">+</button>
              </div>
            `;
            })
            .join("")}
      </div>

      <hr/>
      <p class="hint" style="opacity:.8; font-size:.9em;">
        Roll will combine everything into one roll (e.g. 1d6 + 2d4).
      </p>
    </form>
  `;

    const dlg = new Dialog({
        title: `${titleLabel} Roll`,
        content,
        buttons: {
            roll: {
                icon: '<i class="fas fa-dice"></i>',
                label: "Roll",
                callback: async (html) => {
                    const inputs = html.find("input.dice-term").toArray();
                    const terms = inputs.map((i) => i.value.trim()).filter(Boolean);

                    if (terms.length === 0) {
                        ui.notifications?.warn("No dice terms to roll.");
                        return;
                    }

                    const combined = buildCombinedFormula(terms);
                    await rollCombinedToChat(combined, titleLabel, terms);
                },
            },
            close: { label: "Close" },
        },
        default: "roll",
    });

    dlg.render(true);
}

async function rollCombinedToChat(combinedFormula, titleLabel, terms) {
    try {
        const roll = await new Roll(combinedFormula).evaluate({ async: true });
        await roll.toMessage({
            flavor: `${titleLabel}: ${terms.join(" + ")}`,
            speaker: ChatMessage.getSpeaker(),
        });
    } catch (err) {
        console.error(err);
        ui.notifications?.error(`Invalid combined roll: ${combinedFormula}`);
    }
}
