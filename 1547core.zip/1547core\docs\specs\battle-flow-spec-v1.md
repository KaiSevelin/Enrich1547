# Battle Flow Spec v1 — the whole combat loop

**Status: Reference (as-built).** This describes how a fight actually runs in `1547core`
today — the round/side model, the attack lifecycle, maneuvers, reactions, dice, positioning,
defense, damage, and critical points — and how the pieces wire together across files and
across clients. It is descriptive (what the code does), with a final section listing the
**known gaps and fragilities** that explain the live-test issues. Companion specs go deeper on
individual areas (facing, cross-client reactions, maneuver schema, dice resolution); this is
the map that connects them.

---

## 1. Components at a glance

| Concern | Where it lives |
|---|---|
| Round / side initiative | `combat-tracker/side-tracker.js`, `hud/actor-hud.js` (Side Ready) |
| Turn cues | `combat/turn-cues.js` |
| Attack lifecycle (pure) | `combat/lifecycle-flow.mjs` (`declareAttackPhased`, `resolveAttackOutcomePhased`, `executeResolvedReactionPhased`) |
| Attack orchestration (live) | `services/combat-resolver-service.js` (`declareAttack`, `resolveAttackOutcome`, `runPhases`) |
| HUD attack action | `hud/hud-actions.js` (`executeWeaponAttackAction`) |
| Maneuver legality | `combat/maneuver-legality.mjs` (`getLegalManeuvers`, `evaluateManeuverLegality`) |
| Reaction candidates | `combat/reaction-candidates.mjs` |
| Reaction window + relay | `services/reaction-service.js`, `services/remote-window-relay.js` |
| Post-maneuver relay | `combat/post-maneuver-relay.js` |
| Defense summary | `combat/defense-summary.js` |
| Dice (custom terms + totals) | `dice/*.js`, `dice/dice1547.js` (`accumulateDice1547Totals`, `computeDice1547Totals`) |
| Pools | `combat/pool-builder.mjs` |
| Positioning / facing | `lib/positioning.mjs`, `combat/facing.mjs` |
| Damage / HP | `combat/hp-state.mjs` |
| Conditions | `services/condition-registry.js` |
| Event bus (local, in-memory) | `services/event-bus.js`, `services/combat-events.js` |

**Two execution layers.** The *pure* layer (`combat/*.mjs`) computes patches and emits events
through an injected `run(...)`; it never touches Foundry directly. The *orchestration* layer
(`services/combat-resolver-service.js`) supplies `runPhases` — it applies patches via the
dispatcher and emits combat events. This keeps the math unit-testable and the Foundry glue thin.

**The event bus is local.** `emitCombatEvent` (`combat-events.js`) runs handlers **in-process on
the acting client only**, and it **awaits each async handler in order** (`event-bus.js` `emit`).
Nothing crosses the socket by itself — cross-client behaviour is added explicitly by the relay
(§7). This single fact drives most of the cross-client design.

---

## 2. The round / side model (side-based initiative)

Combat is **side-based**: combatants belong to a *side* (team), and a whole side activates at
once. Standard per-combatant initiative order is **not** used to sequence turns.

- **Side membership** — `combatant.flags.1547core.sideId` (`getStoredSideId`); defaults derived
  from token disposition (`deriveDefaultSideId`: friendly→`team-1`, hostile→`team-2`). The GM can
  override via **Assign Teams** (`showTeamAssignmentDialog`). `DEFAULT_TEAM_IDS = ["team-1","team-2"]`.
- **Active side** — `combat.flags.1547core.activeSideId` (`getActiveSideId`), with `sideOrder`
  and `roundNumber` flags. `combat.turn` is pointed at the **first non-defeated combatant of the
  active side** (`getFirstCombatantIndexForSide`); `combat.round` is the Foundry round.
- **Side Ready** ends a side's activation (`announceSideReady` → `getNextStoredSideTurnState` →
  `advanceCombatToNextSide`): it sets `combat.turn`/`round` and writes the side flags. The next
  side is the next entry in `sideOrder` **that has a non-defeated member**; wrapping increments
  the round.
- **GM-authoritative writes.** `persistCombatSideState` and `advanceCombatToNextSide` write the
  Combat doc, which only the GM may do (`persistCombatSideState` early-returns for non-GMs). A
  player's Side Ready therefore **emits a socket request** (`side-advance-request`) and the GM
  performs the advance; the player builds the chat announcement from the local preview.
- **Turn cues** (`turn-cues.js`) are socket-free: every client watches `updateCombat`, reads the
  propagated `activeSideId`, and a **player** is nudged "Your side's turn" when their side becomes
  active (deduped per combat; the GM is not nudged).
- **Initiative rolls** are forced public (`combat/public-initiative.js` wraps
  `Combat#rollInitiative` with `rollMode: public`) so both GM and players see them. Initiative
  rolls do not sequence side turns; they exist only if the table uses them for ordering.

> **Edge case — a fully-defeated side.** `getNextStoredSideTurnState` filters out defeated
> combatants, so if the opposing side is entirely defeated it is skipped and the search **wraps
> back to the surviving side** (round +1). Side Ready then reports "now: \<same side\>". This is
> as-coded, not a routing failure. See §12.

---

## 3. Action economy (per side activation)

Within a side's activation an actor may take **pre-maneuvers**, one **attack** (or a
**full-turn** action), **movement**, and **reactions** when others act. Budgets are passed into
legality as context (`fullTurnAvailable`, `attacksRemaining`, `movementBudgetRemaining`):

- `full-turn` maneuvers require `fullTurnAvailable !== false`.
- `attack-declared` pre-maneuvers require `attacksRemaining > 0` (when a finite budget is given).
- `move-declared` maneuvers require `movementBudgetRemaining > 0` (when given).

> **Action economy is MANUAL for now**, and **reactions are not budget-gated.**
> `passesActionEconomyGate` checks only the attack/movement budgets, and the reaction path passes
> neither — so reactions are never "used up," and the attack/movement budgets are not auto-reset
> (the GM manages them by hand between activations).
>
> **Reaction economy (✅ implemented):** a reaction (e.g. **Face**) is available **once per round**
> and **renews each new round** — `combat/activation-state.mjs` keys the spent state by
> `${combatId}:${round}`, so it renews automatically when the round advances. `reaction-service`
> withholds the window when the reactor has no reaction left and marks it spent on use (via the Move
> 1 dispatcher). Whether a *specific* reaction like Face is *offered* is still a separate, geometric
> question — see §8 — and facing changes are now locked off-turn (§12 #5). See §12 #3.

---

## 4. Maneuvers

A maneuver is a learned item (folder `Maneuvers`, normalized by `normalizeManeuver`) with:
`type` (timing), `triggerType`, `CostType`/`CostAmount`, `effectData`, `requirements`,
`usageLimit`, `tags`, `handlerId`, `targetRules`, `persistence`.

**Timing types** (the windows they appear in):

| `type` | Offered… | Trigger | Cost |
|---|---|---|---|
| `pre` | at attack/move declaration | `attack-declared` / `move-declared` | stat points (reserved on select, spent on commit) |
| `reaction` | in a reaction window | `attack-declared`, `threat-zone-entered`, `damage-taken`, … | usually none / stat points |
| `post` | after damage, in the post-maneuver window | `post-attack` | **CriticalPoints only** |
| `full-turn` | when declaring a full-turn action | `full-turn-activation` | consumes move+attack; may create a persistent effect (e.g. overwatch) |

**Legality** — `getLegalManeuvers({actor, …context})` → `evaluateManeuverLegality` runs ordered
gates and keeps only `legal` ones: timing → trigger (`matchesTrigger`, honours `alternateTriggers`)
→ usage limit → action economy → actor-state (conditions; e.g. Evade blocked in medium+ armour) →
defense follow-up (parry lock) → weapon → profile (`appliesTo` melee/ranged) → range → target-state
(target conditions, flanking/adjacent ally) → resource (cost pool, incl. `CriticalPoints` for
`post`). Returned candidates are bare maneuver objects (no `.actor`) — relevant to reaction
routing (§7).

**`effectData` vocabulary** (consumed by `normalizeAppliedAttackModifiers` /
`normalizeDefenseModifiers` and the resolver): pool mods (`addMainDice`, `addDisadvantage`,
`addMultiplierDice`, `addRiskDice`, `addMoveSquares`); attack shape (`safeAttack`,
`createFreeSafeAttack`, `createFreeSafeCounterattack`, …); defense (`addArmorDice`,
`reduceDamageTaken`, `lockParryingWeaponUntil`); facing (`facingFace`); gating (`appliesTo`,
`useMaxRange`). The resolver only **branches the lifecycle** on `createFreeSafeAttack` /
`createFreeSafeCounterattack` (§5, §6); all other defense effects are applied as *modifiers* to an
attack that still resolves normally.

**HUD selection state** (`hud-state.js`): per-actor selected pre-maneuvers and one full-turn
maneuver; a FIFO `postManeuverQueue` of post-maneuver windows; the active `reactionWindow` /
`damageTakenWindow`.

---

## 5. The attack lifecycle (phase by phase)

Entry point: `executeWeaponAttackAction` (`hud/hud-actions.js`). It runs **on the attacker's
client** (usually the GM). Sequence:

1. **Legality / reach** — `refreshedAttackState` must be `valid`; otherwise it warns and aborts.
   Reach uses `getChebyshevDistanceSquares` (token-center Chebyshev, diagonal = 1) against the
   weapon's `minReach`/`maxReach` (melee default 1,1) or range bands.
2. **Auto-face + positioning** — `autoFaceAttacker` rotates the attacker to face the target;
   `getAttackPositioning` detects surprise / rear / faceable (§8). The positional result is passed
   into the declaration so the reaction window can offer **Face**.
3. **Declare** — `declareAttack(...)` → `declareAttackPhased` emits `ATTACK_DECLARED`. This is the
   **reaction seam** (§6): `reaction-service` may open a reaction window here and block until it
   resolves. `declareAttack` returns `{ pendingAttack, cancelled, reactionResolution }`.
   - If `cancelled` (a *replacing* reaction — free safe attack/counterattack) → the HUD stops; the
     reaction-resolution path takes over (§6).
4. **Apply positional advantage (post-reaction)** — the rear **+1** is computed **now**, after the
   window: if the defender took **Face** (`reactionResolution.reaction.effectData.facingFace`), the
   advantage is dropped (they turned to meet the blow); otherwise the detected advantage stands.
   The attack formula is rebuilt with the advantage die.
5. **Attack roll** — `rollFormulaToChatAndSummarize` evaluates the pool, posts the roll **public**
   (so both clients animate it), and reads totals **directly from the evaluated roll**
   (`computeRollTotals`), with the Dice So Nice flag/hook as fallback. (Reading totals only from the
   DSN completion hook used to break resolution — see §12.)
6. **Defense roll (automatic).** Once the reaction window resolves, the defender's armour pool
   (`buildDefenseRollFormula` → `buildDefenderPool`, default three Evade dice) is **auto-rolled** —
   the defender does **not** roll it by hand. It is rolled on the **acting (GM) client**, not the
   defending player's. Always rolled on the non-replacing path. (The GM may possess/control a
   player's token to act for them when needed.)
7. **Resolve** — `resolveAttackOutcome({ pendingAttack, attackRoll, defenseRoll, defenseReaction })`
   → `resolveAttackOutcomePhased`: normalize rolls, apply multiplier, apply the chosen
   **defenseReaction** modifiers (`addArmorDice`, `reduceDamageTaken`), compute damage (§9), emit
   `DAMAGE_APPLIED`, build **post-maneuver windows** (§10), emit `ACTION_COMMITTED`.
8. **Damage-taken reaction — partial.** The engine has a *post-damage* reaction: a free **safe
   counterattack** the defender may take after being hit (`executeSafeCounterattackPhased`;
   `normalizeDefenseModifiers` reads `damageTakenReaction.effectData.createFreeSafeCounterattack`;
   `buildDamageTakenPrompt` exposes `commitSafeCounterattack`). This is **machinery only today** —
   the main attack flow does not open a damage-taken window to capture `currentDamageTakenReaction`,
   and the `DAMAGE_TAKEN_WINDOW_OPENED` event is presently **reused** for the informational defense
   summary (§7), not the safe-counterattack prompt. See §12.
9. **Cards** — a public **Attack Result** chat card is posted; a **defense summary** window is
   pushed to the defender's client (`defense-summary.js`, §7).

Phases 5–7 sit *after* the reaction window: the window opens between formula-build and roll, which
is the seam the +1 timing and the defenseReaction both respect.

---

## 6. Reactions

A reaction lets the **defender** (or a threatened actor) respond when something is declared.

- **Trigger** — `reaction-service.handleReactionTrigger` listens for `ATTACK_DECLARED` and
  `THREAT_ZONE_ENTERED`. It builds candidates (`buildAttackReactionCandidates` →
  `getLegalManeuvers` for `triggerType:"attack-declared"`), and — when the shot is a **faceable
  rear** hit — prepends the synthetic **Face Attacker** candidate (`buildFaceReactionCandidate`,
  `effectData:{facingFace:true}`).
- **The reactor** is the **defender** — for an attack that is `reactionWindow.target` (the
  declaration's `actor` is the *attacker*). Because normal maneuver candidates carry no `.actor`,
  the reactor is resolved trigger-aware: `attack → target`, `threat-zone → actor`.
- **Selection** — a single-settle controller (`createReactionSelectionController`) resolves to the
  chosen candidate (or null on pass/timeout, default 10 s). Resolution emits `REACTION_RESOLVED`.
- **What a reaction does to the attack:**
  - **Free safe attack / counterattack** → `handleReactionTrigger` **cancels** the declaration;
    `executeResolvedReactionPhased` (wired via `onCombatEvent(REACTION_RESOLVED)` in
    `combat-resolver-service`) re-resolves it as the counter.
  - **Plain defense reaction** (Desperate Defense, Evade, …) → **does NOT cancel**; the attack
    resolves normally and the reaction's `effectData` modifiers are applied in `resolveAttackOutcome`
    via `defenseReaction`.
  - **Face** → does not cancel; `registerFacingService` (on `REACTION_RESOLVED`) rotates the
    defender to meet the attacker, and the HUD drops the rear +1 (§5 step 4).

> Only free safe attack/counterattack reactions take the cancel-and-re-resolve path. Everything
> else is a *modifier* on an attack that still rolls and posts a card. (Cancelling those was the
> bug behind "Evade voided the whole attack".)

**Timing & one-per-window.** The defender reacts **before any dice are rolled** — the window opens
at declaration, between formula-build and roll, so reactions are chosen *blind* to the attack
result. A window grants **one** choice: picking **Face** (or any defense reaction) **is** the
reaction for that attack and precludes a second one. After the choice resolves, the defense roll is
**auto-rolled** (§5 step 6). Reactions are intended to renew **once per round** (§3, §12).

### Cross-client routing (§7 is the transport)

Because the bus is local, the reaction prompt is **relayed** to the reactor's owner and mirrored
for the GM:

- **GM attacks a player** → window shown on **both** the GM (mirror) and the player (relay);
  first response wins (single-settle); resolving on one closes the other.
- **Player attacks a GM NPC** → window shown **only on the GM** (the attacking player never sees
  the NPC's options).
- Rule in code: the acting client opens the window locally when **it is not relaying** (it owns the
  reactor) **or it is the GM**.

---

## 6A. Movement, threat zones & overwatch

Combat is not only attacks — moving through a threatened space can provoke reactions, and a
full-turn **overwatch** stance lets an actor strike movers. This is the second resolution path,
parallel to the attack lifecycle (§5).

- **Trigger (✅ wired).** `combat/movement-reactions.js` watches `updateToken`: when a combatant
  moves, the **GM** (authoritative) computes the move path and, for each opposing live combatant
  whose threat reach the path approaches, calls `declareMovement` with **one threat event per
  reactor** (not per square). `declareMovementPhased` emits `MOVEMENT_STARTED` then a
  `THREAT_ZONE_ENTERED` per event (`reactor` + `distanceSquares`), resolving through the **same
  reaction machinery** as an attack (§6) — relayed to each reactor's owner.
- **Economy (per-mover, per-round).** A reactor gets **one** movement reaction against a **given
  mover per round** (`isMovementReactionAvailable` / `planMarkMovementReacted`, separate from the
  attack economy). It is spent on **resolution — pass or use** — so declining the first opportunity
  doesn't re-trigger on the mover's later steps; a different opponent can still react.
- **The shot resolves.** A threat/overwatch reaction that grants a free attack is now **rolled and
  resolved** (`resolveFreeAttack` in the resolver — attacker roll → target defense →
  `resolveAttackOutcome` → card), scoped to the `threat-zone` trigger so it never double-fires with
  the attack-side safe counterattack (§5 step 8).
- **Overwatch** is a **full-turn persistent effect** (`createsPersistentEffect:"overwatch"`,
  `persistent-effects.mjs`). While active, the actor gains a synthetic **overwatch reaction
  candidate** (`buildOverwatchReactionCandidate`) — a free ranged/reach shot — offered on
  `THREAT_ZONE_ENTERED` when a mover enters their zone (tagged
  `generatedByPersistentEffect:"overwatch"`).
- **Consumption** — taking the overwatch reaction consumes the effect
  (`planConsumePersistentEffect(actor,"overwatch")`, run by `reaction-service` on selection). Also,
  **declaring an attack against a target consumes that target's overwatch**
  (`declareAttackPhased` plans `planConsumePersistentEffect(pendingAttack.target,"overwatch")`) —
  being attacked spends a held overwatch.
- **Cross-client** — threat/overwatch reaction prompts ride the same relay (§7): the prompt goes to
  the reactor's owner; resolution and combat writes stay on the acting/authoritative client (§7,
  §12).

---

## 7. Cross-client architecture

The generic hub is `services/remote-window-relay.js`:

- `relayRemoteWindow({ kind, windowId, responderActor, request, timeoutMs, onResolve, expectsResponse })`
  picks responder users (`pickResponders`: controlling players, else the GM when a player can't
  decide), sends a socket request on `module.1547core`, shows a persistent "waiting…" indicator,
  and resolves via `onResolve(candidateId|null)`; `closeRelayedWindow` / first-wins close /
  `userConnected` re-send are built in.
- `registerRemoteWindowPresenter(kind, present)` — the responder side renders the window and
  returns `{promise, close}` (or nothing for an informational window).

Consumers: **reactions** (`reaction-service`, HUD reaction prompt with dialog fallback),
**defender post-maneuver windows** (`post-maneuver-relay`, dialog; the acting client still runs
`commitPostManeuver`), and the informational **defense-summary** window (`defense-summary`, pushed
to the defender's HUD). The side-advance request (§2) rides the same channel.

### Write authority — the actual model (and a gap)

The intended model is **GM-authoritative**: combat resolution and all document writes happen on a
client that can write the affected actors — in practice **the GM**. The relay delegates only the
*prompt and the choice*; the acting client owns the timeout, the resolution, and the writes.

**But this is only partly enforced.** The patch dispatcher (`applyPatch` in
`combat-resolver-service.js`) calls `actor.update` / `setFlag` / `setActorStatusEffect`
**directly on whatever client is resolving** — there is no routing to the GM. The acting client is
*whoever attacks*. So:

- **GM attacks anyone** → the GM resolves and writes → fine (the GM can write any actor). This is
  the supported path today, and the GM may possess/control a player token to act for them.
- **A player attacks a GM-owned actor** → the *player* is the acting client → patches to the
  unowned target (HP, status, token rotation from a resolved Face/counterattack) **fail on
  permission** and the effect silently does not apply.

Only the **side-advance** write is currently routed to the GM (`side-advance-request`, §2). The
attack-resolution patches are **not** routed — so **player-initiated attacks on GM-owned actors do
not yet apply their writes.** The required fix is a patch-relay: when the acting client lacks
permission for a patch's target, forward the patch set to a GM client to apply. Tracked in §12 (#1).

---

## 8. Positioning & facing

Pure geometry in `lib/positioning.mjs`; live glue in `combat/facing.mjs`.

- **Token descriptor** — `{col,row,w,h,rotation}` from `doc.x/y/width/height/rotation` over the
  grid size. Distance for reach/positioning is **Chebyshev on token centers** (diagonal counts as
  one square).
- **Rear cone** — `rearConeTiles(defender, maxDist)` is the arc behind the defender's facing out to
  `maxDist` (1×1 at reach 1 = 3 tiles; 2×2 = 4). `isInRearCone(defender, attacker)` tests the
  attacker's footprint against it.
- **`computePositionalAdvantage`** → `{ surprise, rear, advantage(0|1), faceable }`:
  - target **not in combat** → **surprise** (+1, not faceable);
  - else **rear** = attacker in the defender's rear cone → +1, **faceable** unless the attacker is
    Hidden.
- **Auto-face** turns the *attacker* to face the target on every attack (tagged `facingAutoFace`).
- **Face reaction** turns the *defender* to face the attacker; the +1 is recomputed/dropped at HUD
  step 4. Surprise / Hidden +1 are auto-applied and never reach a faceable window.

> Reach and rear both depend on the **defender's current facing**, which **persists** (there is no
> off-turn rotation lock yet, §12). So after a defender Faces attacker A, a later attack by A from
> the same tile is *frontal* (correctly no Face). Whether Face is offered is purely "is the attacker
> in the defender's current rear cone", not a function of turns.

---

## 9. Dice, defense, damage

### Custom dice (6 faces each; `accumulateDice1547Totals`)

| Die (code) | 1 | 2 | 3 | 4 | 5 | 6 |
|---|---|---|---|---|---|---|
| Armor `a` | fumble | – | prot+1 | prot+2 | prot+4 | crit |
| Balanced `b` | fumble | – | dmg+1 | dmg+1 | dmg+2 | crit |
| Control `c` | fumble | – | – | dmg+1 | crit | crit |
| Evade `e` | fumble | – | prot+1 | prot+2 | crit | crit |
| Finesse `g` | – | – | dmg+1 | dmg+1 | crit | crit |
| Heavy `h` | fumble | fumble | dmg+1 | dmg+2 | dmg+4 | crit |
| Lethality `l` | fumble | fumble | dmg+2 | dmg+3 | dmg+5 | crit |
| Multiplier `x` | mult×0 | – | – | mult+1 | mult+1 | mult+2 |
| Penetration `p` | fumble | – | dmg+1 | dmg+1 | dmg+3 | crit |
| Risk `r` | mult×0 | fumble | fumble | – | dmg+2 | crit |

Totals shape: `{ damage, protection, crit, fumble, multiplier }`. `multiplier = multiply ×
multiplyFail` (a Multiplier/Risk "1" zeroes the multiplier). Totals are computed **from the
evaluated roll** (`computeDice1547Totals`); the Dice So Nice completion hook keeps a flag + result
card as a secondary path.

### Pools (`pool-builder.mjs`)

- **Attack** — `buildAttackPool(baseDice, {advantageCount, addMainDice, addMultiplierDice,
  addRiskDice, extraDice, ammoAddDice})`. Advantage **prepends** copies of the first die;
  disadvantage adds **Risk** dice. `toFoundryFormula` maps names → terms (`Balanced→db`, etc.).
- **Defense** — `buildDefenderPool(defenseDice)`; **fallback three Evade** when unarmoured.
  Conditions add Risk dice (`buildDefenseRollFormula` + `conditionCombatDisadvantage`).

### Resolution math (`resolveAttackOutcomePhased`)

1. Normalize both rolls; **apply multiplier** to damage/protection/crit.
2. `protection += defenseModifiers.addArmorDice` (from the chosen `defenseReaction`).
3. `baseDamage = max(0, attack.damage − defense.protection − reduceDamageTaken)`.
4. Secondary/on-hit effects (gated by trigger mode, base-damage-passed, save/contest) add to
   `secondaryDamage`. `damageApplied = base + secondary`.
5. **Critical points** are **per-token**: the attacker's post-maneuver window sees `attack.crit`,
   the defender's sees `defense.crit` — each token spends only the crits *it* rolled (see §10).

### Damage / HP (`hp-state.mjs`)

`planApplyDamage` writes `system.props.CurrentHitPoints` and toggles status effects: `dead`
when HP ≤ 0, `unconscious` when 0 < HP ≤ 1. (`dead` alone marks the outcome — by ruling we no
longer also set a `defeated` *status*. The Foundry **combatant** `defeated` flag is synced
separately — it gates movement-reaction targeting and the tracker — and is kept.)

### Conditions (`condition-registry.js`)

Weakened (physical −1), Exhausted (all −1, blocks advantage), Cursed (all −1), Doomed (blocks
advantage), Locked (combat disadvantage on attack & defense). `conditionCombatDisadvantage` →
Risk-die count added to combat pools; `blocksAdvantage` zeroes advantage dice.

---

## 10. Critical points & post-maneuvers

After damage, both sides may spend **critical points** on `post` maneuvers.
`currentCriticalPoints = attack.crit + defense.crit` — the crit faces from **both** rolls of the
exchange.

**Pool rule (by ruling, 2026-06-17): crits are PER-TOKEN, not shared.** Only the token that rolled
a crit may spend it: the **defender** spends `defense.crit` on its post-maneuver window, the
**attacker** spends `attack.crit` on its own — neither can spend the other's. Crits **expire at the
end of the exchange** (not banked across activations) and are the currency for **critical
maneuvers**, each of which carries its **own crit cost** (variable per maneuver). *(This overrides
the earlier "shared per side" rule.)*

`resolveAttackOutcomePhased` builds `defenderPostOptions` and `attackerPostOptions`
(`getLegalManeuvers` with `timingType:"post"`, `triggerType:"post-attack"`) and emits a
`POST_MANEUVER_WINDOW_OPENED` per non-empty window (**defender first, then attacker**), each window
seeing **only its own token's crit count**. Each carries a `commitPostManeuver(selection)` closure
(the actual combat write, which spends the maneuver's crit cost) and is queued in the HUD; a
defender window owned by a remote player is **relayed** to them (§7) while the acting client
executes the chosen maneuver. Unspent crits are cleared when the window closes.

`resolveAttackOutcomePhased` computes `attackerCriticalPoints` / `defenderCriticalPoints` separately
and feeds each window its own; it also returns their **sum** as `currentCriticalPoints` purely for
the informational Attack Result card. The per-maneuver crit cost is the maneuver's
`CostAmount` (with `CostType: "CriticalPoints"`), enforced by `passesResourceGate` in
`maneuver-legality.mjs`.

---

## 11. One full exchange (worked example)

1. GM selects an attacker, targets a player's PC, clicks the weapon attack.
2. Reach OK; attacker auto-faces; positioning detects a **faceable rear** hit.
3. `ATTACK_DECLARED` → reaction window opens with **Face Attacker** + any legal defenses; it shows
   on the GM (mirror) **and** the player (relay); GM sees "waiting…".
4. Player picks **Face** → defender rotates; first-wins closes the GM mirror.
5. Back on the GM: the rear +1 is **dropped** (Face); the attack pool is built without it.
6. Attack and defense rolls fire **public** (both clients animate); totals read from the rolls.
7. `resolveAttackOutcome` subtracts protection, applies any defense-reaction modifiers, computes
   damage, writes HP, posts the **Attack Result** card, pushes a **defense summary** to the player.
8. If the exchange produced crits, defender then attacker get **post-maneuver** windows (relayed to
   the player as needed).
9. When the side is done, **Side Ready** advances to the other side (player → socket → GM).

---

## 12. Known gaps & fragilities (the live-test backlog)

1. **Combat write routing — ✅ done (patch dispatcher).** `applyPatches` routes any patch a player
   can't apply to the designated GM over `module.1547core` (`patch-apply`); the GM-acting path is
   unchanged. Covers **all** combat writes — `actor.update`/`setFlag`/`statusEffect`, plus
   `token.update` (the facing rotations, via `rotateTokenAuthoritative`) and `combatant.update` (the
   `defeated` sync). So a **player attacking a GM NPC** applies damage/status/defeated and a
   player-provoked NPC Face rotates, all via the GM. *Needs a two-client live test.* See
   `combat-architecture-evolution-spec-v1.md` Move 1.
2. **Damage-taken safe-counterattack — ✅ built (needs two-client live test).** When the defender's
   defense reaction grants a free safe counterattack (`defenseModifiers.safeCounterattack`, e.g.
   `maneuvers.json:1172`), the acting client now offers it to the defender (relay, or local dialog)
   and, on accept, resolves it fully — declare (`executeSafeCounterattack`) → attack roll → the
   original attacker's defense roll → `resolveAttackOutcome` → card. See `hud-actions.js`
   (`offerSafeCounterattack`/`runSafeCounterattack`), `combat/safe-counterattack.js`,
   `combat-architecture-evolution-spec-v1.md` B3. **2026-07-11:** the relay is the ONLY
   counterattack path — the damage-taken window's parallel button/binding
   (`commitSafeCounterattack`, never populated) was deleted; that window is purely the
   informational defense summary.
3. **Reaction renewal — ✅ implemented.** A reaction is now **once per round** and renews each round
   (`combat/activation-state.mjs`, keyed `${combatId}:${round}`; gated + marked in `reaction-service`
   via the Move 1 dispatcher). Attack/movement economy stays **manual** (by ruling). Note: a
   *specific* reaction like Face is *also* gated by geometry (§8) and the off-turn facing lock (#5),
   so "Face missing" can still be correct geometry even with a reaction available.
4. **Reach measurement — ✅ nearest-edge footprint distance.** Reach/adjacency now uses
   `footprintDistanceSquares` (min Chebyshev between the attacker's and target's occupied tiles;
   `lib/positioning.mjs`, unit-tested) instead of center-to-center. Touching footprints (orthogonal
   or diagonal) read distance 1, overlap reads 0, so large tokens and the recurring "diagonal out of
   reach" case resolve correctly. 1×1-vs-1×1 is unchanged. *Needs a live check with a 2×2 token.*
5. **Off-turn facing lock — ✅ implemented (rotation).** `facing.mjs registerFacingLock` is a
   `preUpdateToken` veto: a player may not rotate an in-combat token off its side's activation
   (bypasses: GM, `facingAutoFace`, `facingForced`, non-combatants). Facing is now a rule, not a
   convention. *Movement* (x/y) is intentionally **not** locked yet — rotation only (movement is more
   intrusive; enable on request).
6. **Fully-defeated opposing side — ✅ resolved (announce + GM prompt).** When only one side still
   has non-defeated combatants, the GM client posts a victory chat banner and asks "End combat?"
   (`side-tracker.js checkForSideVictory`, riding the `updateCombatant` defeated sync). Never
   auto-ends — reinforcements/surrender stay possible; declining doesn't re-prompt
   (`victoryAnnounced` combat flag, cleared if a second side revives). *Needs a live test.*
7. **Dice totals once depended on Dice So Nice.** Now read from the evaluated roll
   (`computeRollTotals`) with the DSN hook as fallback — keep new combat math off the animation hook.
8. **Multiplier — ✅ resolved.** Both the direct `computeDice1547Totals` path and the Dice So Nice
   flag path now compute `multiply × multiplyFail`, so a bonus (e.g. ×2) and a **multiply-fail (×0)**
   carry through identically. Rule: a **0 multiplier cancels ALL damage / protection / crit**
   (`applyMultiplier` applies a finite 0; a missing/invalid multiplier means ×1). The readers
   preserve a stored `0` (no `|| 1` coercion). Unit-tested in `combat-attack-lifecycle.test.mjs`.
9. **Face does not roll a separate defense** — it cancels the rear +1 and turns the defender. If
   Face should *also* let a normal defense roll, thread it like the other defense reactions.
10. **Multi-target — deferred by ruling (2026-07-11); single-target is canonical.** `declareAttack`
    now clamps `targets[]` to the first target with a warning; area/multi-target resolution (per-
    defender reactions, crits, damage windows) is future work to be specced as its own vertical
    slice. Ammo economy (`planConsumeLoadedAmmo`, `ammoAddDice`, reload) still needs its own
    treatment.
11. **Crit pool per-token — ✅ reconciled.** `resolveAttackOutcomePhased` now feeds the defender
    window `defenderCriticalPoints` and the attacker window `attackerCriticalPoints` (each its own
    roll's crits, never pooled); `currentCriticalPoints` survives only as their sum for the result
    card. Per-maneuver crit cost is the maneuver's `CostAmount` (`CostType: "CriticalPoints"`),
    gated in `maneuver-legality.mjs passesResourceGate`. Unit-tested in
    `combat-lifecycle-flow.test.mjs` (per-token split). See §10 and §13.

---

## 13. Canonical rulings (owner, 2026-06-17)

The combat-design decisions these specs/code must follow (also in agent memory `project-combat-rules`):

- **Economy is fully manual** — no engine enforcement of attacks, actions, or movement distance; the
  engine only *reacts* to movement (overwatch), never limits it.
- **Turn flow:** the active side acts until it calls **Side Ready** (no take-backs), then the other
  side; once **both** sides have readied the **round advances** (which renews reactions and ticks
  round-clocked effects).
- **Initiative:** rolled **once per combat** (3d6 per side); the resulting side order is **fixed for
  every round** — never re-rolled.
- **Defense is always free/unlimited;** the once-per-round reaction economy gates only *extras*
  (Face, free counterattack, overwatch). Reaction **triggers are a closed set: attack + movement.**
- **Crits are per-token, expire end of exchange,** and buy **critical maneuvers** at a variable
  per-maneuver cost (see §10).
- **Reach = nearest-edge footprint-to-footprint Chebyshev** (see §12 #4).
- **0 HP → `dead` status only** (the `defeated` *status* is dropped; the combatant `defeated` flag is
  kept for tracker/movement gating). Conditions/effects are **round-clocked**.
- **Arc/indirect overhead-clear** is a manual GM call.

### Rulings added 2026-07-11 (grilling session — effect scaling, costs, windows)

- **Resolution is FLAT — margin of success never scales anything.** Beating defense by 10 equals
  beating it by 1: `damage − protection − reduceDamageTaken`. Multiplier dice (a rolled 0 cancels
  all), crit points and Core-stacking ARE the scaling system. Do not add margin scaling.
- **Pre-maneuver costs are charged ONCE, at commit** — the resolution's `spendReservations` phase
  (`planSpendReservedCosts`). Selection is free and reversible; there is no reserve-on-select and no
  refund path. (The old maneuver-state-spec's reservation model is rejected; the HUD's duplicate
  spend loop was removed as a double-spend bug.)
- **Over-commit is caught at Attack click:** `findOverCommittedPools` sums the selected
  pre-maneuvers' costs per pool at declaration and blocks with a message when a pool is exceeded —
  no silent clamp-at-zero underpayment.
- **Crit points are in-memory and exchange-scoped by design.** They flow resolution result →
  post-window payload → HUD decrement, and die when the window closes. A mid-exchange browser
  refresh losing them is accepted. No actor prop backs them (Convert's `props.CriticalPoints`
  read was vestigial and is removed).
- **Reactions are chosen BLIND at attack declaration** (defender sees attacker/weapon/pre-maneuvers,
  never the roll). No post-roll reaction tier. Only free safe attack/counterattack cancel the
  declaration; everything else is a modifier.
- **Post-maneuver physical effects — automate the easy subset:** rotate-target (8-way, 45°/step)
  and push (straight line away from the attacker, stop at the first wall, no budget spend / no
  opportunity attacks — `forcedManeuverMove`) are automated in `applyPostManeuverEffect`. Disarm,
  swallow, place-adjacent and the grapple-break advantage stay "(GM applies)".
- **Multi-target attacks are deferred** — single-target is canonical (see §12 #10).
- **Spec hygiene:** `combat-spec-v2.md`, `combat-state-machine-v1.md` and `maneuver-state-spec-v1.md`
  were **deleted** as diverging from as-built; THIS document is the single source of truth.

---

## Companion specs
- `facing-and-positioning-spec-v1.md`, `facing-implementation-spec-v1.md` — rules + Face/lock plan.
- `cross-client-reaction-spec-v1.md` — the relay transport (now generalised to all windows).
- `maneuver-schema-spec-v1.md`, `maneuver-legality-and-filtering-spec-v1.md`, `maneuver-rules-guide.md`.
- `dice-resolution-spec-v1.md`, `combat-resolution-loop-spec-v1.md`.
- `cover-spec-v1.md`, `ranged-shot-visualization-spec-v1.md` — not-yet-built ranged work.
