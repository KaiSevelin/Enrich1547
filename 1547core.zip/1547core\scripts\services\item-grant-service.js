/**
 * ItemGrant reconciliation service.
 *
 * Syncs Direct-mode ItemGrant Changes on attached ChangeSets to actual
 * embedded items on the actor. Granted items are tagged with a
 * `flags["1547core"].grantedBy = { changeSetId, changeId }` marker so
 * subsequent reconciliations can find and remove them when the parent
 * ChangeSet (or the individual Change) goes away.
 *
 * RollTable-mode ItemGrant is also supported: the source item ID is read
 * from the Change's cached roll (`flags["1547core"].rolledResult.sourceItemId`,
 * populated by rolltable-resolution-service). If the cache is missing
 * (roll hasn't happened yet) the Change is skipped — the resolution
 * service will write the cache and the resulting updateItem hook will
 * re-trigger this reconciler.
 *
 * The diff function is pure and exported for testing; the hook glue is
 * GM-only and gated by an options flag to prevent self-trigger recursion.
 */

import { getContainerChildItems, allRefIds } from "./csb-container-helpers.mjs";
import { getItemById } from "./content-registry.js";
import { MODULE_ID, CHANGESET_TEMPLATE_ID, CHANGE_TEMPLATE_ID } from "../lib/constants.mjs";

const CHANGE_CONTAINER_KEY = "ChangeDisplayer";
const FLAG_KEY = "grantedBy";
const RECONCILE_GUARD = "_1547core_reconciling";

function isChangeSet(item) {
    return item?.system?.template === CHANGESET_TEMPLATE_ID;
}

function isChange(item) {
    return item?.system?.template === CHANGE_TEMPLATE_ID;
}

function grantKey(changeSetId, changeId, sourceItemId) {
    return `${changeSetId}::${changeId}::${sourceItemId ?? ""}`;
}

function readGrantedByFlag(item) {
    return item?.flags?.[MODULE_ID]?.[FLAG_KEY] ?? null;
}

/**
 * Pure diff: given an actor and a source-item resolver, compute what
 * embedded items need to be created or deleted to bring the actor in line
 * with the ItemGrant Changes on its attached ChangeSets.
 *
 * @param {Actor|object} actor — must expose `items` iterable
 * @param {(id: string) => object|null} resolveSource — returns a plain item
 *   data object for a given source item ID, or null if unresolvable
 * @returns {{ toCreate: object[], toDelete: string[] }}
 */
export function computeGrantedItemReconciliation(actor, resolveSource) {
    const targetGrants = new Map();
    const items = Array.from(actor?.items ?? []);

    for (const set of items.filter(isChangeSet)) {
        const childChanges = getContainerChildItems(set, actor, CHANGE_CONTAINER_KEY, CHANGE_TEMPLATE_ID);
        for (const change of childChanges) {
            const props = change.system?.props ?? {};
            // CSB empties ref/container props (Kind is a scalar and survives, but
            // ItemGrantRef is a ref field that data-prep clears) — read the raw
            // `_source` copy for the linkage.
            const sourceProps = change._source?.system?.props ?? {};
            if ((props.Kind ?? sourceProps.Kind) !== "ItemGrant") continue;
            const mode = String(props.ItemGrantMode ?? sourceProps.ItemGrantMode ?? "Direct").trim();
            let sourceItemIds = [];
            if (mode === "Direct") {
                // One ItemGrant Change can grant several items (e.g. Claws +
                // Bite + Natural Armor) — grant them all, not just the first.
                sourceItemIds = allRefIds(sourceProps.ItemGrantRef ?? props.ItemGrantRef);
            } else if (mode === "RollTable") {
                const rolled = change.flags?.[MODULE_ID]?.rolledResult?.sourceItemId ?? null;
                if (rolled) sourceItemIds = [rolled];
            }
            for (const sourceItemId of sourceItemIds) {
                if (!sourceItemId) continue;
                targetGrants.set(grantKey(set.id, change.id, sourceItemId), {
                    changeSetId: set.id,
                    changeId: change.id,
                    sourceItemId
                });
            }
        }
    }

    const existingGranted = new Map();
    for (const item of items) {
        const grantedBy = readGrantedByFlag(item);
        if (!grantedBy?.changeSetId || !grantedBy?.changeId) continue;
        existingGranted.set(grantKey(grantedBy.changeSetId, grantedBy.changeId, grantedBy.sourceItemId), item);
    }

    const toDelete = [];
    for (const [key, item] of existingGranted) {
        if (!targetGrants.has(key)) toDelete.push(item.id);
    }

    const toCreate = [];
    const unresolved = [];
    for (const [key, target] of targetGrants) {
        if (existingGranted.has(key)) continue;
        const sourceData = resolveSource(target.sourceItemId);
        if (!sourceData) {
            unresolved.push(target);
            continue;
        }
        const itemData = JSON.parse(JSON.stringify(sourceData));
        delete itemData._id;
        // CSB uses system.container as a back-pointer that scopes the
        // item to a parent itemContainer (e.g. an ItemGrantRef field).
        // When that's set, the item only renders inside that container,
        // not in the actor's main inventory panels (Weapons / Armor /
        // etc.). Strip it so the granted copy is a free-floating
        // inventory item.
        if (itemData.system && itemData.system.container !== undefined) {
            delete itemData.system.container;
        }
        // Auto-equip: if the source has an Equipped prop (weapons, armor,
        // shields, etc.), flip it on so a granted weapon is ready to use
        // without the GM having to click each one. Items that don't have
        // the concept (consumables, notes, etc.) are left alone.
        if (itemData.system?.props && "Equipped" in itemData.system.props) {
            itemData.system.props.Equipped = true;
        }
        itemData.flags = itemData.flags ?? {};
        itemData.flags[MODULE_ID] = itemData.flags[MODULE_ID] ?? {};
        itemData.flags[MODULE_ID][FLAG_KEY] = {
            changeSetId: target.changeSetId,
            changeId: target.changeId,
            sourceItemId: target.sourceItemId
        };
        toCreate.push(itemData);
    }

    return { toCreate, toDelete, unresolved };
}

function defaultResolveSource(id, actor) {
    if (!id) return null;
    // Check the reconciling actor's own items FIRST. CSB's drop handler
    // creates the source item directly on the open actor (as a
    // container-scoped "ghost") when you drag into an ItemGrantRef
    // field, so the id usually only resolves here. This also covers
    // token-actor cases where `game.actors` doesn't enumerate the
    // synthetic actor we're reconciling for.
    const ownOnActor = actor?.items?.get?.(id);
    if (ownOnActor) return ownOnActor.toObject();
    // The content registry (world items overlaid on the compendium packs) —
    // natural weapons like Bite/Claws/Natural Armor live in the weapons pack and
    // may not exist as standalone world items.
    const registryItem = getItemById(id);
    if (registryItem) return registryItem.toObject();
    // Then world items
    const worldItem = globalThis.game?.items?.get?.(id);
    if (worldItem) return worldItem.toObject();
    // Last resort: scan every world actor
    const actors = globalThis.game?.actors;
    if (actors) {
        for (const other of actors) {
            const owned = other.items?.get?.(id);
            if (owned) return owned.toObject();
        }
    }
    return null;
}

/**
 * Reconcile granted items on an actor. GM-only; no-op for non-GMs and for
 * `_template` actors.
 */
export async function reconcileGrantedItems(actor, { resolveSource } = {}) {
    if (!actor || actor.documentName !== "Actor") return;
    if (actor.type === "_template") return;
    // Bind the actor into the default resolver so it can check the
    // reconciling actor's own items (where CSB's drop handler places
    // the source).
    if (!resolveSource) resolveSource = (id) => defaultResolveSource(id, actor);
    if (!globalThis.game?.user?.isGM) return;

    const { toCreate, toDelete, unresolved } = computeGrantedItemReconciliation(actor, resolveSource);

    if (unresolved?.length) {
        for (const u of unresolved) {
            console.warn(`${MODULE_ID} | ItemGrant source not resolvable: actor=${actor.name} changeSet=${u.changeSetId} change=${u.changeId} sourceItemId=${u.sourceItemId}`);
        }
    }

    if (toDelete.length === 0 && toCreate.length === 0) return;

    const options = { [RECONCILE_GUARD]: true };
    if (toDelete.length) {
        await actor.deleteEmbeddedDocuments("Item", toDelete, options);
    }
    if (toCreate.length) {
        await actor.createEmbeddedDocuments("Item", toCreate, options);
    }
}

function shouldTriggerReconcile(item, options) {
    if (options?.[RECONCILE_GUARD]) return false;
    // Both ChangeSets and Changes live directly on the actor (CSB does not
    // nest Item-in-Item). Trigger when either kind is created / updated /
    // deleted on an actor. Granted items themselves are guarded by
    // RECONCILE_GUARD above.
    if (item?.parent?.documentName !== "Actor") return false;
    return isChangeSet(item) || isChange(item);
}

function actorFromItem(item) {
    return item?.parent?.documentName === "Actor" ? item.parent : null;
}

export function registerItemGrantService() {
    Hooks.on("createItem", (item, options) => {
        if (!shouldTriggerReconcile(item, options)) return;
        const actor = actorFromItem(item);
        if (actor) void reconcileGrantedItems(actor);
    });
    Hooks.on("updateItem", (item, _change, options) => {
        if (!shouldTriggerReconcile(item, options)) return;
        const actor = actorFromItem(item);
        if (actor) void reconcileGrantedItems(actor);
    });
    Hooks.on("deleteItem", (item, options) => {
        if (!shouldTriggerReconcile(item, options)) return;
        const actor = actorFromItem(item);
        if (actor) void reconcileGrantedItems(actor);
    });

    const moduleApi = game.modules.get(MODULE_ID);
    if (!moduleApi) {
        console.warn(`${MODULE_ID} | registerItemGrantService: module not found`);
        return;
    }
    moduleApi.api = moduleApi.api ?? {};
    moduleApi.api.reconcileGrantedItems = reconcileGrantedItems;
    moduleApi.api.computeGrantedItemReconciliation = computeGrantedItemReconciliation;
}
