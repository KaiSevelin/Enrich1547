import { MODULE_ID } from "../lib/constants.mjs";
/**
 * Universal item hover-card service.
 *
 * On hover over an item row in an actor sheet or compendium, opens a styled
 * info panel via Foundry's TooltipManager.
 *
 * 0.3.13: defanged after a regression where HUD elements got pointerenter
 * handlers and tooltip activation interfered with HUD click behaviour.
 * This pass restricts decoration to true item rows on actor sheets and
 * compendiums; HUD-specific selectors are removed.
 */

const TOOLTIP_CLASS = "hover-card-1547core";

const TEMPLATE_LABELS = {
    "qZCfLEYQ7egbm1B9": "Weapon",
    "uLlgZXz3GlXPFtsj": "Armor",
    "389uqkKKn8M1SKux": "Ammunition",
    "WmP9Ld3Qs7Nk2FvR": "Weapon Modifier",
    "2kiWw3Cv5Zk1lZxn": "Spell",
    "M0nMgk7Yp2RsT5Vu": "Monster Power",
    "4owc4YQBlp94GbGs": "Maneuver",
    "w9ky0ZTDvXDs5Ce7": "Supernatural Mark",
    "HPYYc2P0Ouagicmr": "Pact",
    "Qv6pN2Lm8R4tY1Ks": "Ritual",
    "R7sTu4Qn2Lp8Vx5K": "Ritual Step",
    "mwPqEYUoOfzXpyT9": "Usage Effect",
    "b7A1z6cSZO4dYTKT": "Change Set",
    "WsrkfjBmudnIhvEK": "Change",
    "L4ujYgqhGBGcoo2P": "Requirement",
    "OnH1tEffectTmpl0": "On-Hit Effect",
    "eCIZRFXbcQVZKqEr": "Equipment"
};

function escapeHtml(s) {
    return String(s ?? "")
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function getCategoryLabel(item) {
    const props = item?.system?.props ?? {};
    if (typeof props.Category === "string" && props.Category.trim()) return props.Category.trim();
    if (typeof props.Group === "string" && props.Group.trim()) return props.Group.trim();
    const templateId = item?.system?.template;
    if (templateId && TEMPLATE_LABELS[templateId]) return TEMPLATE_LABELS[templateId];
    return item?.type ?? "Item";
}

function getDescriptionHtml(item) {
    const props = item?.system?.props ?? {};
    const flagSrc = item?.flags?.["1547Core"]?.sourceData ?? {};
    return String(
        props.Description ?? props.Notes ?? flagSrc.description ?? flagSrc.notes ?? ""
    ).trim();
}

function getAttachedModifiers(item) {
    if (!item?.parent?.items?.get) return [];
    const flags = item.flags ?? {};
    const ids = flags["1547Core"]?.attachedModifierIds
        ?? flags["1547core"]?.attachedModifierIds
        ?? item.system?.props?.AttachedModifierIds
        ?? [];
    const list = Array.isArray(ids) ? ids : [];
    return list.map((id) => item.parent.items.get(id)).filter(Boolean);
}

function buildModifierBlock(item) {
    const modifiers = getAttachedModifiers(item);
    if (!modifiers.length) return "";
    const rows = modifiers.map((m) => {
        const p = m.system?.props ?? {};
        const detailParts = [];
        if (p.AddDice) detailParts.push(`+${p.AddDice}`);
        if (p.AddDamageQualifiers) detailParts.push(p.AddDamageQualifiers);
        if (p.OverrideDamageType) detailParts.push(p.OverrideDamageType);
        if (p.RemoveDice) detailParts.push(`-${p.RemoveDice}`);
        const detail = detailParts.length ? ` <span style="color:#5e4f38;">(${escapeHtml(detailParts.join(", "))})</span>` : "";
        return `<li>${escapeHtml(m.name)}${detail}</li>`;
    }).join("");
    return `<div class="hc-divider"></div><div class="hc-modifiers"><strong>Modifiers:</strong><ul style="margin:0.2rem 0 0 1.2rem;padding:0;">${rows}</ul></div>`;
}

function buildStatsLine(item) {
    const p = item?.system?.props ?? {};
    const parts = [];
    if (p.Weight !== undefined && p.Weight !== null && p.Weight !== 0) parts.push(`Weight ${p.Weight}`);
    if (p.Value !== undefined && p.Value !== null && p.Value !== 0) parts.push(`Value ${p.Value}`);
    if (p.WeaponType) parts.push(p.WeaponType);
    if (p.ArmorType) parts.push(p.ArmorType);
    if (p.Attack) parts.push(p.Attack);
    if (p.Defense) parts.push(p.Defense);
    if (p.MaxRange) parts.push(`Range ${p.MaxRange}`);
    if (p.UsageLimit) parts.push(`${p.UsageLimit}×/turn`);
    if (p.Complexity) parts.push(`${p.Complexity} ritual`);
    if (p.MagicKind) parts.push(p.MagicKind);
    if (p.MarkNature && p.MarkScope) parts.push(`${p.MarkScope} ${p.MarkNature}`);
    if (p.PactType) parts.push(p.PactType);
    return parts.join(" · ");
}

async function buildHoverCardHtml(item) {
    try {
        if (!item) return "<div class='hc-head'><div class='hc-meta'><div class='hc-name'>No item</div></div></div>";
        const img = escapeHtml(item.img ?? "icons/svg/item-bag.svg");
        const name = escapeHtml(item.name ?? "Item");
        const category = escapeHtml(getCategoryLabel(item));
        const descRaw = getDescriptionHtml(item);
        let desc = "";
        if (descRaw) {
            try {
                const enricher = globalThis.foundry?.applications?.ux?.TextEditor?.implementation?.enrichHTML
                    ?? globalThis.TextEditor?.enrichHTML;
                if (typeof enricher === "function") {
                    const result = await enricher(descRaw, { async: true });
                    desc = typeof result === "string" ? result : descRaw;
                } else {
                    desc = descRaw;
                }
            } catch {
                desc = descRaw;
            }
        }
        const stats = buildStatsLine(item);
        const modifiers = buildModifierBlock(item);
        const html = `<div class="hc-head"><img class="hc-img" src="${img}" alt="" /><div class="hc-meta"><div class="hc-name">${name}</div><div class="hc-category">${category}</div></div></div>${desc ? `<div class="hc-divider"></div><div class="hc-desc">${desc}</div>` : ""}${stats ? `<div class="hc-divider"></div><div class="hc-stats">${escapeHtml(stats)}</div>` : ""}${modifiers}`;
        return html;
    } catch (err) {
        console.warn(`${MODULE_ID} | hover-card buildHtml failed`, err);
        return `<div class='hc-head'><div class='hc-meta'><div class='hc-name'>${escapeHtml(item?.name ?? "Item")}</div><div class='hc-category'>error rendering</div></div></div>`;
    }
}

// Single shared panel element — avoids version-dependent TooltipManager
// behavior in v13 where `game.tooltip.activate()` silently no-ops. Nested
// decorated elements all share this panel: hovering the inner element fires
// pointerenter for it, panel content updates, single panel always visible.
let sharedPanel = null;
const PANEL_ID = "hover-card-1547core-panel";
const PANEL_OFFSET = 14;

function ensurePanel() {
    if (sharedPanel && document.body.contains(sharedPanel)) return sharedPanel;
    sharedPanel = document.createElement("div");
    sharedPanel.id = PANEL_ID;
    sharedPanel.classList.add(TOOLTIP_CLASS);
    sharedPanel.style.cssText = "position:fixed;z-index:99999;pointer-events:none;display:none;max-width:340px;";
    document.body.appendChild(sharedPanel);
    return sharedPanel;
}

function positionPanel(panel, x, y) {
    // Default: right of cursor. If it would overflow viewport, flip to left.
    const rect = panel.getBoundingClientRect();
    let posX = x + PANEL_OFFSET;
    if (posX + rect.width > window.innerWidth - 8) posX = x - rect.width - PANEL_OFFSET;
    if (posX < 8) posX = 8;
    let posY = y;
    if (posY + rect.height > window.innerHeight - 8) posY = window.innerHeight - rect.height - 8;
    if (posY < 8) posY = 8;
    panel.style.left = posX + "px";
    panel.style.top = posY + "px";
}

function showPanel(html, x, y) {
    const panel = ensurePanel();
    panel.innerHTML = html;
    panel.style.display = "block";
    // Position twice: once to lay out so we know dimensions, then again
    // with the now-known size for accurate flip / clamp.
    positionPanel(panel, x, y);
    requestAnimationFrame(() => positionPanel(panel, x, y));
}

function hidePanel() {
    if (sharedPanel) sharedPanel.style.display = "none";
}

// Per-element binding is fragile when CSB re-renders the actor sheet —
// re-renders destroy our bound elements, leaving fresh items without
// handlers. Instead we use a single document-level mousemove listener
// (delegation) plus closest() ancestor lookup. Robust to re-renders.

const HOVER_HTML_CACHE = new WeakMap();
let currentHoveredEl = null;
let currentHoveredItem = null;

function findHoverableAncestor(target, actor = null) {
    if (!target?.closest) return { el: null, item: null, unresolvedAncestor: null };
    const selectors = [
        "[data-uuid]",
        "[data-item-id]",
        "[data-document-id]",
        "[data-entry-id]",
        "[data-hud-weapon-profile]",
        "[data-hud-weapon-attack]",
        "[data-hud-weapon-range]",
        "[data-hud-weapon-reload]",
        "[data-hud-weapon-ammo]",
        "[data-hud-item-equip]",
        "[data-hud-item-unequip]",
        "[data-hud-open-item]",
        "[data-hud-maneuver-select]",
        "[data-hud-pre-maneuver]"
    ];
    let firstAncestor = null;
    for (const sel of selectors) {
        const el = target.closest(sel);
        if (!el) continue;
        if (!firstAncestor) firstAncestor = el;
        const item = findItemForElement(el, actor);
        if (item) return { el, item, unresolvedAncestor: null };
    }
    return { el: null, item: null, unresolvedAncestor: firstAncestor };
}

function findActorForElement(el) {
    // Look up the chain for a sheet-rendered window with a recognised actor.
    // CSB sheets stamp the actor uuid as data-uuid on the window root.
    const winRoot = el.closest("[data-uuid], .window-app");
    if (!winRoot) return null;
    const uuid = winRoot.dataset?.uuid;
    if (uuid) {
        try {
            const doc = fromUuidSync?.(uuid);
            if (doc?.documentName === "Actor") return doc;
        } catch { /* non-fatal */ }
    }
    return null;
}

function installDelegatedHoverListener() {
    if (globalThis._hoverCard1547DelegationInstalled) return;

    let lastLoggedUnresolved = null;
    // Attach at the CAPTURE phase on document. CSB v13 sheets call
    // stopPropagation on pointer events in their bubble-phase handlers,
    // preventing document.body from receiving them. Capture fires BEFORE
    // any bubble handlers — we get the event regardless of who stops what.
    document.addEventListener("pointermove", async (event) => {
        try {
            const actor = findActorForElement(event.target);
            const { el, item, unresolvedAncestor } = findHoverableAncestor(event.target, actor);

            if (el !== currentHoveredEl) {
                // Hover target changed.
                currentHoveredEl = el;
                currentHoveredItem = item;
                if (!el || !item) {
                    // Surface unresolved-ancestor info even when el is null,
                    // so we can diagnose IDs that fail to resolve to items.
                    if (globalThis.HoverCard1547_DEBUG && unresolvedAncestor && unresolvedAncestor !== lastLoggedUnresolved) {
                        const id = unresolvedAncestor.dataset?.itemId
                            ?? unresolvedAncestor.dataset?.documentId
                            ?? unresolvedAncestor.dataset?.entryId;
                        console.log(`${MODULE_ID} | matched ancestor ${unresolvedAncestor.tagName} id=${id} but no item resolves`);
                        lastLoggedUnresolved = unresolvedAncestor;
                    }
                    hidePanel();
                    return;
                }
                if (globalThis.HoverCard1547_DEBUG) console.log(`${MODULE_ID} | hover enter:`, item.name);
                let html = HOVER_HTML_CACHE.get(item);
                if (!html) {
                    html = await buildHoverCardHtml(item);
                    HOVER_HTML_CACHE.set(item, html);
                    if (globalThis.HoverCard1547_DEBUG) console.log(`${MODULE_ID} | hover html ready, length:`, html?.length);
                }
                // User may have moved off during enrichment.
                if (currentHoveredItem !== item) return;
                showPanel(html || "<div>(empty)</div>", event.clientX, event.clientY);
                if (globalThis.HoverCard1547_DEBUG) console.log(`${MODULE_ID} | panel shown`);
            } else if (el && sharedPanel?.style.display === "block") {
                // Same element, just track the cursor.
                positionPanel(sharedPanel, event.clientX, event.clientY);
            }
        } catch (err) {
            console.warn(`${MODULE_ID} | delegated hover handler failed`, err);
        }
    }, true); // capture phase

    globalThis._hoverCard1547DelegationInstalled = true;
    console.log(`${MODULE_ID} | delegated hover listener installed (capture phase on document)`);
}

function attachTooltipHandlers(_el, _item) {
    // No-op: handled by document-level delegation in installDelegatedHoverListener.
}

const VALID_FOUNDRY_ID = /^[A-Za-z0-9]{16}$/;

function findItemForElement(el, actor) {
    // data-uuid: Foundry content-links + many CSB cells point to items
    //            with a fully-qualified UUID like
    //            "Scene.X.Token.Y.Actor.Z.Item.W". fromUuidSync handles
    //            actor-embedded and token-actor items directly.
    const uuid = el.dataset?.uuid;
    if (uuid && typeof globalThis.fromUuidSync === "function") {
        try {
            const doc = globalThis.fromUuidSync(uuid);
            if (doc?.documentName === "Item") return doc;
        } catch { /* fall through */ }
    }
    const d = el.dataset;
    // data-item-id: classic Foundry actor sheets / inventory grids
    // data-document-id: compendium browser, sidebar item directory
    // data-entry-id: CSB v13 grid renderer
    // data-hud-*: 1547core HUD rows (weapons / armor / inventory / marks)
    const id = d?.itemId ?? d?.documentId ?? d?.entryId
        ?? d?.hudWeaponProfile ?? d?.hudWeaponAttack ?? d?.hudWeaponRange
        ?? d?.hudWeaponReload ?? d?.hudWeaponAmmo
        ?? d?.hudItemEquip ?? d?.hudItemUnequip
        ?? d?.hudOpenItem
        ?? d?.hudManeuverSelect ?? d?.hudPreManeuver;
    if (!id) return null;
    if (!VALID_FOUNDRY_ID.test(id)) return null;
    if (actor?.items?.get) {
        const x = actor.items.get(id);
        if (x) return x;
    }
    const worldItem = globalThis.game?.items?.get?.(id);
    if (worldItem) return worldItem;
    for (const a of globalThis.game?.actors?.contents ?? []) {
        const x = a.items?.get?.(id);
        if (x) return x;
    }
    for (const token of globalThis.canvas?.tokens?.placeables ?? []) {
        const x = token.actor?.items?.get?.(id);
        if (x) return x;
    }
    return null;
}

function decorateRoot(root, actor) {
    try {
        if (!root?.querySelectorAll) return 0;
        const candidates = root.querySelectorAll("[data-item-id], [data-document-id], [data-entry-id]");
        let decorated = 0;
        for (const el of candidates) {
            try {
                const item = findItemForElement(el, actor);
                if (item) {
                    attachTooltipHandlers(el, item);
                    decorated++;
                }
            } catch (err) {
                console.warn(`${MODULE_ID} | hover-card per-element failure`, err);
            }
        }
        // Log unconditionally when debug is on so a "0 decorated" outcome is
        // distinguishable from "hook didn't fire" during diagnosis.
        if (globalThis.HoverCard1547_DEBUG) {
            console.log(`${MODULE_ID} | hover-card: scanned ${candidates.length} candidate elements, decorated ${decorated}`);
        }
        return decorated;
    } catch (err) {
        console.warn(`${MODULE_ID} | hover-card decorateRoot failed`, err);
        return 0;
    }
}

function normalizeRoot(html) {
    if (!html) return null;
    if (typeof HTMLElement !== "undefined" && html instanceof HTMLElement) return html;
    if (html?.[0] && typeof html[0].querySelectorAll === "function") return html[0];
    if (typeof html === "object" && typeof html.querySelectorAll === "function") return html;
    return null;
}

function findActor(app) {
    return app?.actor ?? app?.object?.actor ?? app?.document?.parent ?? null;
}

export function registerItemHoverCardService() {
    const handler = (app, html) => {
        try {
            // v13 sometimes passes a chrome-only fragment as `html` before
            // the inner content mounts. Fall through to app.element (the
            // mounted DOM after _onRender) or document.body so we don't miss.
            const candidates = [normalizeRoot(html), app?.element, document.body].filter(Boolean);
            const actor = findActor(app);
            for (const root of candidates) {
                const decorated = decorateRoot(root, actor);
                // Stop at the first non-empty scan — no point repeating work.
                if (decorated > 0) break;
            }
        } catch (err) {
            console.warn(`${MODULE_ID} | hover-card render-hook failed`, err);
        }
    };

    // Install the single document-level delegated listener. This replaces
    // the per-element pointerenter binding and is robust to CSB re-renders.
    installDelegatedHoverListener();

    // Render-hook decoration kept only for the diagnostic count log.
    Hooks.on("renderActorSheet", handler);
    Hooks.on("renderApplication", handler);
    Hooks.on("renderApplicationV2", handler);
    Hooks.on("renderCompendium", handler);
    Hooks.on("renderItemDirectory", handler);

    console.log(`${MODULE_ID} | item-hover-card service registered`);

    // Always-on global so you can verify the service loaded even if module.api
    // hasn't been attached yet by some race condition.
    globalThis.HoverCard1547 = {
        rescan: (rootEl) => decorateRoot(rootEl ?? document.body, null),
        enableDebug: () => { globalThis.HoverCard1547_DEBUG = true; console.log(`${MODULE_ID} | hover-card debug ON`); },
        disableDebug: () => { globalThis.HoverCard1547_DEBUG = false; console.log(`${MODULE_ID} | hover-card debug OFF`); },
        buildHtml: buildHoverCardHtml
    };

    try {
        const moduleApi = globalThis.game?.modules?.get?.(MODULE_ID);
        if (moduleApi) {
            moduleApi.api = moduleApi.api ?? {};
            moduleApi.api.hoverCard = globalThis.HoverCard1547;
        }
    } catch (err) {
        console.warn(`${MODULE_ID} | hover-card api attach failed`, err);
    }
}
