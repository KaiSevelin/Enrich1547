export function buildReactionPrompt(deps = {}) {
    const {
        getActiveReactionWindow,
        getReactionCountdownText,
        getSelectedReactionChoiceId,
        normalizeReactionChoiceId,
        getManeuverCostSummary,
        getManeuverEffectSummary,
        getManeuverTimingSummary,
        buildManeuverDetailLine,
        getCoreStackCount,
        getReactorActor,
        escapeHtml,
    } = deps;

    const reactionWindow = getActiveReactionWindow?.();
    if (!reactionWindow) return "";

    // Core-reaction stacking: the reactor can stage extra Core Points on a Core
    // reaction (Core Defense / Core Toughness) before committing. Ceiling =
    // staged + still-available. The reactor is the actor whose HUD is showing
    // (injected) — reactionWindow.actor is the ATTACKER for attack windows,
    // which used to clamp the ceiling to the wrong actor's pool.
    const reactorActor = typeof getReactorActor === "function" ? getReactorActor() : null;
    const reactorId = reactorActor?.id ?? null;
    // Raw CorePoints is the live pool on the actor template; AvailableCorePoints
    // only exists on legacy derived-model actors.
    const reactorProps = reactorActor?.system?.props ?? {};
    const availableCore = Math.max(0, Number(reactorProps.AvailableCorePoints ?? reactorProps.CorePoints ?? 0) || 0);

    const actorName = reactionWindow.actor?.name ?? "";
    const targetName = reactionWindow.target?.name ?? "";
    let actorTargetSummary = "";
    if (actorName && targetName) {
        actorTargetSummary = `${actorName} -> ${targetName}`;
    } else if (actorName) {
        actorTargetSummary = actorName;
    } else if (targetName) {
        actorTargetSummary = targetName;
    }

    const summaryParts = [
        reactionWindow.trigger === "attack" ? "Attack Reaction" : "Threat Reaction",
        actorTargetSummary,
        `Closes in ${getReactionCountdownText?.(reactionWindow) ?? "0.0s"}`,
        Array.isArray(reactionWindow.candidates) && reactionWindow.candidates.length ? `${reactionWindow.candidates.length} option${reactionWindow.candidates.length === 1 ? "" : "s"}` : ""
    ].filter(Boolean);

    const selectedId = getSelectedReactionChoiceId?.();
    const candidateButtons = (Array.isArray(reactionWindow.candidates) ? reactionWindow.candidates : []).map((candidate) => {
        const choiceId = normalizeReactionChoiceId?.(candidate) ?? "";
        const label = candidate?.name || choiceId || "Reaction";
        const isDisabled = candidate?.legal === false;
        const isSelected = selectedId === choiceId;
        const activeClass = isSelected ? " is-active" : "";
        const disabledAttr = isDisabled ? " disabled" : "";
        const firstReason = Array.isArray(candidate?.reasons) ? String(candidate.reasons[0] ?? "").trim() : "";
        const subtitleParts = [
            getManeuverCostSummary?.(candidate),
            getManeuverEffectSummary?.(candidate),
            [candidate?.usage, candidate?.type].filter(Boolean).join(" - ")
        ].filter(Boolean);
        const subtitle = subtitleParts.join(" | ") || (isDisabled ? firstReason : getManeuverTimingSummary?.(candidate) || "");
        const detail = buildManeuverDetailLine?.(candidate) || "";
        const tooltip = [firstReason, subtitle, detail].filter(Boolean).join(" | ");
        // Core reactions get a gem stepper: left-click +1 Core Point, right-click
        // −1. The staged count scales the reaction's effect + cost on commit.
        const usesCore = String(candidate?.CostType ?? candidate?.source?.CostType ?? "") === "CorePoints";
        const maneuverId = candidate?.id ?? candidate?._id ?? candidate?.source?.id ?? candidate?.name ?? "";
        const staged = usesCore && reactorId && typeof getCoreStackCount === "function"
            ? getCoreStackCount(reactorId, maneuverId) : 0;
        const stackControl = usesCore && !isDisabled
            ? `<button type="button" class="hud-mini-button hud-core-stack-btn is-core-cost" data-hud-core-stack="${escapeHtml(maneuverId)}" data-hud-core-max="${staged + availableCore}" title="Core Points staged: ${staged}. Left-click +1, right-click −1."><i class="fa-solid fa-gem hud-core-icon" aria-hidden="true"></i>&times;${Math.max(1, staged)}</button>`
            : "";
        return `
            <button
                type="button"
                class="hud-mini-button${activeClass}"
                data-hud-reaction-choice="${escapeHtml(choiceId)}"
                title="${escapeHtml(tooltip)}"
                aria-pressed="${isSelected ? "true" : "false"}"
                ${disabledAttr}
            >
                ${escapeHtml(label)}
                <span class="hud-mini-button-sub">${escapeHtml(subtitle)}</span>
                ${detail ? `<span class="hud-mini-button-sub">${escapeHtml(detail)}</span>` : ""}
            </button>
            ${stackControl}
        `;
    }).join("");

    return `
        <section class="hud-tree-block hud-reaction-banner hud-prompt-window hud-prompt-window-reaction">
            <div class="hud-prompt-eyebrow-row">
                <div class="hud-section-title">Reaction Window</div>
                <span class="hud-prompt-chip">Reaction</span>
            </div>
            <div class="hud-row-main">${escapeHtml(summaryParts[0] ?? "Reaction")}</div>
            <div class="hud-row-sub">${escapeHtml(summaryParts.slice(1).join(" - "))}</div>
            <div class="hud-chip-row hud-reaction-actions">
                ${candidateButtons ? candidateButtons : '<span class="hud-empty-pill">No legal reactions</span>'}
                ${selectedId ? '<button type="button" class="hud-mini-button is-active" data-hud-reaction-commit>Commit</button>' : ''}
                <button type="button" class="hud-mini-button" data-hud-reaction-pass>Pass</button>
            </div>
        </section>
    `;
}

export function buildDamageTakenPrompt(deps = {}) {
    const {
        getActiveDamageTakenWindow,
        escapeHtml,
    } = deps;

    const damageWindow = getActiveDamageTakenWindow?.();
    if (!damageWindow) return "";

    const attackerName = damageWindow.pendingAttack?.actor?.name ?? "";
    const defenderName = damageWindow.pendingAttack?.target?.name ?? "";
    const summaryParts = [
        "Damage Taken",
        attackerName && defenderName ? `${attackerName} -> ${defenderName}` : (attackerName || defenderName),
        Number.isFinite(Number(damageWindow.damageApplied)) ? `Damage ${damageWindow.damageApplied}` : "",
        Number.isFinite(Number(damageWindow.hitPointUpdate?.currentHitPoints))
            ? `HP ${damageWindow.hitPointUpdate.currentHitPoints}`
            : ""
    ].filter(Boolean);

    const defenseSummary = [
        Number(damageWindow.defenseModifiers?.addArmorDice ?? 0) > 0 ? `+${damageWindow.defenseModifiers.addArmorDice} armor` : "",
        Number(damageWindow.defenseModifiers?.reduceDamageTaken ?? 0) > 0 ? `-${damageWindow.defenseModifiers.reduceDamageTaken} damage` : "",
        damageWindow.defenseModifiers?.safeCounterattack ? "Safe counterattack" : "",
        String(damageWindow.defenseFollowUpState?.lockedParryingWeaponUntil ?? "").trim() ? `Parry lock: ${damageWindow.defenseFollowUpState.lockedParryingWeaponUntil}` : ""
    ].filter(Boolean).join(" | ");

    const selectedReactionName = damageWindow.selectedReaction?.name ?? damageWindow.defenseReaction?.name ?? "";

    return `
        <section class="hud-tree-block hud-reaction-banner hud-prompt-window hud-prompt-window-defense">
            <div class="hud-prompt-eyebrow-row">
                <div class="hud-section-title">Defense Summary</div>
                <span class="hud-prompt-chip">Defense</span>
            </div>
            <div class="hud-row-main">${escapeHtml(summaryParts[0] ?? "Defense")}</div>
            <div class="hud-row-sub">${escapeHtml(summaryParts.slice(1).join(" - "))}</div>
            ${selectedReactionName ? `<div class="hud-row-sub">${escapeHtml(selectedReactionName)}</div>` : ""}
            ${defenseSummary ? `<div class="hud-row-sub">${escapeHtml(defenseSummary)}</div>` : ""}
            <div class="hud-chip-row hud-reaction-actions">
                <button type="button" class="hud-mini-button" data-hud-damage-taken-close>Close</button>
            </div>
        </section>
    `;
}

export function buildPostManeuverPrompt(deps = {}) {
    const {
        getActivePostManeuverWindow,
        getSelectedPostManeuverId,
        normalizePostManeuverChoiceId,
        buildManeuverSummaryLine,
        buildManeuverDetailLine,
        escapeHtml,
    } = deps;

    const postWindow = getActivePostManeuverWindow?.();
    if (!postWindow) return "";

    const actorName = postWindow.actor?.name ?? "";
    const targetName = postWindow.target?.name ?? "";
    const summaryParts = [
        postWindow.side === "defender" ? "Defender Post Maneuver" : "Attacker Post Maneuver",
        actorName && targetName ? `${actorName} -> ${targetName}` : (actorName || targetName),
        Number.isFinite(Number(postWindow.currentCriticalPoints)) ? `Crit ${postWindow.currentCriticalPoints}` : ""
    ].filter(Boolean);

    const selectedId = getSelectedPostManeuverId?.(postWindow.id);
    const choiceButtons = (Array.isArray(postWindow.legalPostManeuvers) ? postWindow.legalPostManeuvers : []).map((candidate) => {
        const choiceId = normalizePostManeuverChoiceId?.(candidate) ?? "";
        const activeClass = selectedId === choiceId ? " is-active" : "";
        const subtitle = buildManeuverSummaryLine?.(candidate) || "";
        const detail = buildManeuverDetailLine?.(candidate) || "";
        return `
            <button
                type="button"
                class="hud-mini-button${activeClass}"
                data-hud-post-choice="${escapeHtml(choiceId)}"
            >
                ${escapeHtml((candidate?.name ?? choiceId) || "Post Maneuver")}
                <span class="hud-mini-button-sub">${escapeHtml(subtitle)}</span>
                ${detail ? `<span class="hud-mini-button-sub">${escapeHtml(detail)}</span>` : ""}
            </button>
        `;
    }).join("");

    return `
        <section class="hud-tree-block hud-reaction-banner hud-prompt-window hud-prompt-window-critical">
            <div class="hud-prompt-eyebrow-row">
                <div class="hud-section-title">Post Maneuver Window</div>
                <span class="hud-prompt-chip">Critical</span>
            </div>
            <div class="hud-row-main">${escapeHtml(summaryParts[0] ?? "Post Maneuver")}</div>
            <div class="hud-row-sub">${escapeHtml(summaryParts.slice(1).join(" - "))}</div>
            <div class="hud-chip-row hud-reaction-actions">
                ${choiceButtons || '<span class="hud-empty-pill">No legal post maneuvers</span>'}
                ${selectedId ? '<button type="button" class="hud-mini-button is-active" data-hud-post-commit>Commit</button>' : ''}
                <button type="button" class="hud-mini-button" data-hud-post-pass>Pass</button>
            </div>
        </section>
    `;
}
