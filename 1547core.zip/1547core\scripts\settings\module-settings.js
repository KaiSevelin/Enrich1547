﻿const MODULE_ID = "1547core";
const SOURCE_FLAG_SCOPE = "1547Core";
const TEMPLATE_FILES = {
    actorTemplate: "fvtt-Actor-1547-Tgs09eTiTp63Cp7u.json",
    maneuver: "fvtt-Item-maneuvertemplate-4owc4YQBlp94GbGs.json",
    weapon: "fvtt-Item-weapontemplate-qZCfLEYQ7egbm1B9.json",
    armor: "fvtt-Item-armor-uLlgZXz3GlXPFtsj.json",
    ammo: "fvtt-Item-unequippabletemplate-woHyeHPKKdo4JDJd.json",
    power: "fvtt-Item-powertemplate-w9ky0ZTDvXDs5Ce7.json",
    spell: "fvtt-Item-spelltemplate-2kiWw3Cv5Zk1lZxn.json",
    pact: "fvtt-Item-pacttemplate-HPYYc2P0Ouagicmr.json",
    recipe: "fvtt-Item-recipetemplate-Qv6pN2Lm8R4tY1Ks.json",
    usageEffect: "fvtt-Item-usageeffecttemplate-mwPqEYUoOfzXpyT9.json",
    changeSet: "fvtt-Item-changesettemplate-b7A1z6cSZO4dYTKT.json",
    change: "fvtt-Item-changetemplate-WsrkfjBmudnIhvEK.json",
    requirement: "fvtt-Item-requirementtemplate-L4ujYgqhGBGcoo2P.json"
};
const VALID_FOUNDRY_ID = /^[A-Za-z0-9]{16}$/;
const ACTOR_TYPES = [
    "Player",
    "Spirit",
    "HiddenFolk",
    "TheUnseen",
    "Beast",
    "Undead",
    "Colossal",
    "Cursed",
    "Unnatural",
    "Construct",
    "Zone",
    "People"
];
const CHANGE_SET_GROUPS = ["Domain", "Size", "Role", "Motivation", "Loadout", "Quirk", "Boost"];
const CHANGE_FOLDER_LABELS = {
    Stat: "Stat (Numeric)",
    PrimaryStat: "Primary Stat",
    Skill: "Skill",
    Text: "Text",
    ItemGrant: "Item Grant",
    Tag: "Tag",
    Trait: "Trait"
};
const REQUIREMENT_FOLDER_LABELS = {
    GroupPresent: "Group",
    HasTag: "Tag",
    StatAtLeast: "Stat",
    PrimaryStatAtLeast: "Primary Stat",
    HasSkill: "Skill"
};

function getModuleBasePath() {
    const modulePath = game.modules.get(MODULE_ID)?.path ?? game.modules.get(SOURCE_FLAG_SCOPE)?.path ?? "";
    const normalizedPath = String(modulePath).replace(/\\/g, "/");
    const folderName = normalizedPath.split("/").filter(Boolean).pop();
    return folderName ? `modules/${folderName}` : `modules/${MODULE_ID}`;
}

function isValidFoundryId(value) {
    return VALID_FOUNDRY_ID.test(String(value ?? ""));
}

function deriveFoundryIdFromText(text) {
    const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let hashA = 2166136261;
    let hashB = 16777619;
    const source = String(text ?? "1547CoreItem");
    for (const ch of source) {
        const code = ch.charCodeAt(0);
        hashA ^= code;
        hashA = Math.imul(hashA, 16777619) >>> 0;
        hashB = (Math.imul(hashB ^ code, 2246822519) + 3266489917) >>> 0;
    }

    let output = "";
    for (let i = 0; i < 16; i += 1) {
        hashA = (Math.imul(hashA ^ (hashB >>> (i % 8)), 1664525) + 1013904223) >>> 0;
        output += alphabet[hashA % alphabet.length];
    }
    return output;
}

function normalizeSourceEntry(source, kind, documentType = "Item") {
    const normalized = foundry.utils.deepClone(source);
    let nextId = normalized._id;
    const uuidSuffix = typeof normalized.uuid === "string" ? normalized.uuid.split(".").pop() : "";

    if (!isValidFoundryId(nextId)) {
        if (isValidFoundryId(normalized.id)) {
            nextId = normalized.id;
        } else if (isValidFoundryId(uuidSuffix)) {
            nextId = uuidSuffix;
        } else {
            nextId = deriveFoundryIdFromText(`${kind}:${normalized.name}:${normalized.uuid ?? ""}`);
        }
    }

    normalized._id = nextId;
    normalized.id = nextId;
    normalized.uuid = `${documentType}.${nextId}`;
    return normalized;
}

function mergeDefinedProps(baseProps, overrideProps) {
    const merged = { ...(baseProps ?? {}) };
    for (const [key, value] of Object.entries(overrideProps ?? {})) {
        if (value !== undefined) {
            merged[key] = value;
        }
    }
    return merged;
}

function normalizeTypeList(values) {
    if (Array.isArray(values)) return values.map((entry) => String(entry ?? "").trim()).filter(Boolean);
    if (typeof values === "string" && values.trim()) return [values.trim()];
    return [];
}

function cloneTemplateSystem(template) {
    return {
        body: foundry.utils.deepClone(template.system.body),
        display: foundry.utils.deepClone(template.system.display),
        header: foundry.utils.deepClone(template.system.header),
        hidden: foundry.utils.deepClone(template.system.hidden ?? []),
        modifiers: [],
        template: template._id,
        templateSystemUniqueVersion: template.system.templateSystemUniqueVersion,
        props: {}
    };
}

function normalizeTraitKey(value) {
    return String(value ?? "").replace(/[^A-Za-z0-9]/g, "");
}

function buildWeaponProps(weapon) {
    const traitKeys = [
        "Aiming", "ArmorBreaking", "Bracing", "Charging", "Control",
        "Disarming", "Fast", "Fragile", "Heavy", "Hooking",
        "Narrow", "Parrying", "PointBlank", "RigidBlade",
        "Receiving", "Reloading", "Shield", "SmallShield", "Tactical"
    ];
    const normalizedTraits = new Set((weapon.traits ?? []).map(normalizeTraitKey));
    const [a, b, c] = weapon.attackProfiles ?? [];

    const profileText = (profile) => {
        if (!profile) return "";
        const diceText = Array.isArray(profile.dice) ? profile.dice.join(", ") : "";
        return profile.name && profile.name !== "Default"
            ? `${profile.name}: ${diceText}`
            : diceText;
    };

    const profileAmmoText = (profile) => {
        if (!profile || !weapon.usesAmmo) return "";
        const allowedAmmoTypes = Array.isArray(profile.allowedAmmoTypes) && profile.allowedAmmoTypes.length > 0
            ? profile.allowedAmmoTypes
            : (weapon.ammoType ? [weapon.ammoType] : []);
        return allowedAmmoTypes.join(", ");
    };

    const availableProfiles = [a, b, c]
        .map((profile, index) => profile ? ["Attack", "AttackB", "AttackC"][index] : null)
        .filter(Boolean);
    const sourceActiveProfile = String(weapon.activeAttackProfile ?? "").trim();
    const activeAttackProfile = availableProfiles.includes(sourceActiveProfile)
        ? sourceActiveProfile
        : (availableProfiles[0] ?? "Attack");

    const props = {
        Description: "",
        Weight: weapon.weight ?? 0,
        Value: weapon.value ?? 0,
        Equipped: Boolean(weapon.equipped),
        WeaponType: weapon.category ?? "Blade",
        MinReach: weapon.minReach ?? "",
        MaxReach: weapon.maxReach ?? "",
        ShortRange: weapon.shortRange ?? "",
        LongRange: weapon.longRange ?? "",
        MaxRange: weapon.maxRange ?? "",
        UsesAmmo: Boolean(weapon.usesAmmo),
        AmmoType: weapon.ammoType ?? "",
        AmmoCapacity: weapon.ammoCapacity ?? 0,
        AmmoLoaded: weapon.ammoLoaded ?? 0,
        LoadedAmmoId: weapon.loadedAmmoId ?? "",
        ReloadTime: weapon.reloadTime ?? 0,
        ReloadProgress: weapon.reloadProgress ?? 0,
        Attack: profileText(a),
        AttackAmmo: profileAmmoText(a),
        AttackB: profileText(b),
        AttackBAmmo: profileAmmoText(b),
        AttackC: profileText(c),
        AttackCAmmo: profileAmmoText(c),
        ActiveAttackProfile: activeAttackProfile
    };

    for (const key of traitKeys) {
        props[`Traits_${key}`] = normalizedTraits.has(key);
    }

    return props;
}

function buildArmorProps(armor) {
    const traitKeys = ["Concealable", "Encumbering", "Flexible", "Noisy", "Soft", "Resistance", "VerySoft"];
    const normalizedTraits = new Set((armor.traits ?? []).map(normalizeTraitKey));
    const props = {
        Description: "",
        Weight: armor.weight ?? 0,
        Value: armor.value ?? 0,
        Equipped: Boolean(armor.equipped),
        ArmorType: armor.armorClass ?? "Light",
        Defense: Array.isArray(armor.defenseDice) ? armor.defenseDice.join(", ") : ""
    };

    for (const key of traitKeys) {
        props[`Traits_${key}`] = normalizedTraits.has(key);
    }

    return props;
}

function buildAmmoProps(ammo) {
    const addDice = Array.isArray(ammo.addDice) ? ammo.addDice.join(", ") : "";
    const tags = Array.isArray(ammo.tags) ? ammo.tags.join(", ") : "";
    const range = ammo.range
        ?? (ammo.rangeOverride ? { mode: "override", ...ammo.rangeOverride } : null)
        ?? (ammo.rangeModifier ? { mode: "modify", ...ammo.rangeModifier } : null)
        ?? null;
    return {
        Description: ammo.description ?? "",
        Weight: ammo.weight ?? 0,
        Value: ammo.value ?? 0,
        Quantity: ammo.quantity ?? 1,
        AmmoType: ammo.ammoType ?? ammo.name ?? "",
        AddDice: addDice,
        AddDiceSummary: addDice,
        Tags: tags,
        TagsSummary: tags,
        RangeModeOverride: String(range?.mode ?? "modify").trim().toLowerCase() === "override",
        RangeShort: range?.shortRange ?? 0,
        RangeMedium: range?.longRange ?? 0,
        RangeLong: range?.maxRange ?? 0,
        Range: range ? JSON.stringify(range, null, 2) : "",
        ResultModifiers: JSON.stringify(ammo.resultModifiers ?? [], null, 2)
    };
}

function inferManeuverEffectFamily(maneuver) {
    const tags = new Set(maneuver.tags ?? []);
    if (maneuver.name === "Overwatch") return "prepared-effect";
    if (maneuver.name === "Suppressing Fire") return "battlefield-effect";
    if (tags.has("persistent")) return "prepared-effect";
    if (tags.has("safe-attack")) return "safe-attack";
    if (tags.has("movement")) return "movement";
    if (tags.has("control")) return "control";
    if (tags.has("condition")) return "condition";
    if (tags.has("utility")) return "utility";
    return tags.has("attack-modifier") ? "attack-modifier" : "utility";
}

function inferManeuverPersistentEffectType(maneuver) {
    if (maneuver.name === "Aim") return "aimed";
    if (maneuver.name === "Brace" || maneuver.name === "Brace Firearm") return "braced";
    if (maneuver.name === "Overwatch") return "overwatch";
    if (maneuver.name === "Lock") return "locked";
    if (maneuver.name === "Choke") return "choking-hold";
    return "";
}

function inferManeuverBattlefieldEffectType(maneuver) {
    if (maneuver.name === "Suppressing Fire") return "suppressing-fire";
    return "";
}

function inferManeuverTargetType(maneuver) {
    const effectData = maneuver.effectData ?? {};
    if (effectData.area) return "area";
    if (effectData.target === "visible-ally") return "ally";
    if (effectData.target === "self") return "self";
    if (effectData.target && String(effectData.target).includes("ally")) return "ally";
    if (maneuver.tags?.includes("support")) return "ally";
    return "enemy";
}

function inferManeuverRollType(maneuver) {
    if (maneuver.triggerType === "move-declared" || maneuver.tags?.includes("movement")) return "movement";
    if (maneuver.tags?.includes("defense") || maneuver.triggerType === "damage-taken") return "defense";
    if (maneuver.name === "Grapple Break") return "escape";
    return "attack";
}

function buildManeuverProps(maneuver) {
    const requirements = maneuver.requirements ?? {};
    const usageLimit = maneuver.usageLimit?.maxUses ?? 1;
    const effectFamily = inferManeuverEffectFamily(maneuver);
    const persistentEffectType = inferManeuverPersistentEffectType(maneuver);
    const battlefieldEffectType = inferManeuverBattlefieldEffectType(maneuver);
    const requiredTagParts = [];
    if (Array.isArray(requirements.requiredWeaponTraits) && requirements.requiredWeaponTraits.length > 0) {
        requiredTagParts.push(...requirements.requiredWeaponTraits);
    }
    if (Array.isArray(requirements.requiredWeaponGroups) && requirements.requiredWeaponGroups.length > 0) {
        requiredTagParts.push(...requirements.requiredWeaponGroups);
    }
    if (Array.isArray(requirements.requiredWeaponTags) && requirements.requiredWeaponTags.length > 0) {
        requiredTagParts.push(...requirements.requiredWeaponTags);
    } else if (requirements.requiredWeaponTags) {
        requiredTagParts.push(requirements.requiredWeaponTags);
    }
    const requiredWeaponTags = requiredTagParts.join(", ");
    const excludedWeaponTags = Array.isArray(requirements.excludedWeaponTags)
        ? requirements.excludedWeaponTags.join(", ")
        : (requirements.excludedWeaponTags ?? "");

    return {
        SkillRequirement: requirements.skill ?? "",
        RequirementText: requirements.text ?? "",
        TargetRequirement: requirements.target ?? "",
        RequiredWeaponTags: requiredWeaponTags,
        ExcludedWeaponTags: excludedWeaponTags,
        UsageLimit: usageLimit,
        EffectFamily: effectFamily,
        CreatesPersistentEffect: Boolean(persistentEffectType),
        PersistentEffectType: persistentEffectType,
        CreatesBattlefieldEffect: Boolean(battlefieldEffectType),
        BattlefieldEffectType: battlefieldEffectType,
        EffectData: JSON.stringify(maneuver.effectData ?? {}, null, 2),
        Automated: Boolean(maneuver.automated),
        HandlerId: maneuver.handlerId ?? "",
        Description: "",
        Usage: maneuver.type ?? "pre",
        Trigger: maneuver.triggerType ?? "attack-declared",
        CostType: maneuver.CostType ?? "null",
        CostAmount: maneuver.CostAmount ?? 0,
        TargetType: inferManeuverTargetType(maneuver),
        RollType: inferManeuverRollType(maneuver)
    };
}

function buildChangeSetProps(changeSet) {
    const allowedTypes = new Set(normalizeTypeList(changeSet.appliesTo ?? changeSet.forTypes));
    const props = {
        Notes: changeSet.notes ?? "",
        Group: changeSet.group ?? changeSet.system?.props?.Group ?? "",
        ForTypeAny: changeSet.forTypeAny ?? allowedTypes.size === 0,
        RequirementsDisplayer: changeSet.requirementsDisplayer ?? changeSet.system?.props?.RequirementsDisplayer ?? {},
        ChangeDisplayer: changeSet.changeDisplayer ?? changeSet.system?.props?.ChangeDisplayer ?? {}
    };

    for (const actorType of ACTOR_TYPES) {
        props[`ForType_${actorType}`] = allowedTypes.has(actorType) || changeSet[`ForType_${actorType}`] === true;
    }

    return mergeDefinedProps(props, changeSet.props ?? changeSet.system?.props);
}

function buildChangeProps(change) {
    const props = {
        Kind: change.kind ?? change.system?.props?.Kind ?? "",
        Notes: change.notes ?? "",
        StatTarget: change.statTarget ?? "",
        StatOp: change.statOp ?? "Add",
        StatValue: change.statValue ?? 0,
        PrimaryStatTarget: change.primaryStatTarget ?? "",
        PrimaryStatOp: change.primaryStatOp ?? "Step",
        PrimaryStatSteps: change.primaryStatSteps ?? 0,
        PrimaryStatSetDice: change.primaryStatSetDice ?? 1,
        PrimaryStatSetMod: change.primaryStatSetMod ?? 0,
        SkillRef: change.skillRef ?? [],
        SkillDelta: change.skillDelta ?? 0,
        TextTarget: change.textTarget ?? "",
        TextOp: change.textOp ?? "Append",
        TextValue: change.textValue ?? "",
        ItemGrantMode: change.itemGrantMode ?? "Direct",
        ItemGrantRef: change.itemGrantRef ?? [],
        ItemGrantRollTable: change.itemGrantRollTable ?? "",
        TagName: change.tagName ?? "",
        TraitName: change.traitName ?? "",
        TraitDescription: change.traitDescription ?? "",
        DurationValue: change.durationValue ?? 0,
        DurationUnit: change.durationUnit ?? "Permanent"
    };

    return mergeDefinedProps(props, change.props ?? change.system?.props);
}

function buildRequirementProps(requirement) {
    const props = {
        PredicateType: requirement.predicateType ?? requirement.system?.props?.PredicateType ?? "",
        Negate: requirement.negate ?? false,
        Notes: requirement.notes ?? "",
        GroupTarget: requirement.groupTarget ?? "",
        TagName: requirement.tagName ?? "",
        StatTarget: requirement.statTarget ?? "",
        StatThreshold: requirement.statThreshold ?? 0,
        PrimaryStatRequirementTarget: requirement.primaryStatRequirementTarget ?? "",
        PrimaryStatRequirementDice: requirement.primaryStatRequirementDice ?? 1,
        PrimaryStatRequirementMod: requirement.primaryStatRequirementMod ?? 0,
        RequirementSkillRef: requirement.requirementSkillRef ?? [],
        SkillMinLevel: requirement.skillMinLevel ?? 0
    };

    return mergeDefinedProps(props, requirement.props ?? requirement.system?.props);
}

function makeItemDoc(source, template, img, propsBuilder, folderId, folderHint = null) {
    return {
        _id: source._id,
        name: source.name,
        // Instance items always use CSB's single user-facing item type
        // "equippableItem", NOT the template's own document type
        // ("_equippableItemTemplate", the schema marker). The CSB
        // template choice is carried by system.template, not by
        // Foundry's `type` field.
        //
        // Cannot fall back to `source.type` here because some source
        // datasets (notably maneuvers) overload `type` to mean timing
        // ("pre" / "reaction" / "post" / "full-turn") rather than a
        // Foundry document type. That meaning is preserved inside
        // system.props by the per-kind propsBuilder.
        type: "equippableItem",
        img,
        system: {
            ...cloneTemplateSystem(template),
            props: propsBuilder(source)
        },
        effects: [],
        folder: folderId ?? null,
        flags: {
            "custom-system-builder": {
                version: template.flags?.["custom-system-builder"]?.version ?? "5.2.0"
            },
            [SOURCE_FLAG_SCOPE]: {
                folderHint: folderHint ?? source.folder ?? null,
                sourceData: source
            }
        },
        items: [],
        ownership: { default: 0 }
    };
}

function makeActorDoc(source, folderId, folderHint = null) {
    return {
        _id: source._id,
        name: source.name,
        type: source.type ?? "character",
        img: source.img ?? "icons/svg/mystery-man.svg",
        system: foundry.utils.deepClone(source.system ?? {}),
        prototypeToken: foundry.utils.deepClone(source.prototypeToken ?? {}),
        effects: foundry.utils.deepClone(source.effects ?? []),
        folder: folderId ?? null,
        flags: {
            ...(foundry.utils.deepClone(source.flags ?? {})),
            [SOURCE_FLAG_SCOPE]: {
                folderHint: folderHint ?? source.folder ?? null,
                sourceData: source
            }
        },
        items: foundry.utils.deepClone(source.items ?? []),
        ownership: foundry.utils.deepClone(source.ownership ?? { default: 0 })
    };
}

function makeTemplateDoc(template) {
    return {
        _id: template._id,
        name: template.name,
        type: template.type,
        img: template.img,
        system: foundry.utils.deepClone(template.system),
        effects: foundry.utils.deepClone(template.effects ?? []),
        folder: template.folder ?? null,
        flags: foundry.utils.deepClone(template.flags ?? {}),
        items: foundry.utils.deepClone(template.items ?? []),
        ownership: foundry.utils.deepClone(template.ownership ?? { default: 0 })
    };
}

async function upsertWorldItems(docs) {
    const sourceIds = new Set(docs.map((doc) => doc._id));
    const existingById = new Map(
        game.items.filter((item) => sourceIds.has(item.id)).map((item) => [item.id, item])
    );

    const toCreate = [];
    const toUpdate = [];

    for (const doc of docs) {
        const existing = existingById.get(doc._id);
        if (existing) {
            toUpdate.push({
                ...doc,
                _id: existing.id
            });
        } else {
            toCreate.push(doc);
        }
    }

    if (toCreate.length > 0) {
        await Item.createDocuments(toCreate);
    }

    if (toUpdate.length > 0) {
        // recursive:false → Foundry force-replaces `system` instead of
        // recursive-merging it. Required when an item's CSB template
        // differs between the source data and the existing world item
        // (Foundry sees that as a type change and refuses a merge).
        await Item.updateDocuments(toUpdate, { recursive: false });
    }

    return {
        created: toCreate.length,
        updated: toUpdate.length
    };
}

async function upsertWorldActors(docs) {
    const sourceIds = new Set(docs.map((doc) => doc._id));
    const existingById = new Map(
        game.actors.filter((actor) => sourceIds.has(actor.id)).map((actor) => [actor.id, actor])
    );

    const toCreate = [];
    const toUpdate = [];

    for (const doc of docs) {
        const existing = existingById.get(doc._id);
        if (existing) {
            toUpdate.push({
                ...doc,
                _id: existing.id
            });
        } else {
            toCreate.push(doc);
        }
    }

    if (toCreate.length > 0) {
        await Actor.createDocuments(toCreate);
    }

    if (toUpdate.length > 0) {
        // recursive:false — see comment in upsertWorldItems above.
        await Actor.updateDocuments(toUpdate, { recursive: false });
    }

    return {
        created: toCreate.length,
        updated: toUpdate.length
    };
}

async function pruneManagedFolderItems({ folderId, validIds, templateId, folderHint }) {
    if (!folderId || !(validIds instanceof Set)) {
        return { removed: 0 };
    }

    const staleIds = game.items
        .filter((item) => item.folder?.id === folderId)
        .filter((item) => {
            const sourceFlag = item.flags?.[SOURCE_FLAG_SCOPE] ?? {};
            const itemFolderHint = sourceFlag.folderHint ?? sourceFlag.sourceData?.folder ?? null;
            const usesManagedTemplate = item.system?.template === templateId;
            const isManaged = itemFolderHint === folderHint || usesManagedTemplate;
            return isManaged && !validIds.has(item.id);
        })
        .map((item) => item.id);

    if (staleIds.length > 0) {
        await Item.deleteDocuments(staleIds);
    }

    return { removed: staleIds.length };
}

async function pruneManagedFolderActors({ folderId, validIds, folderHint }) {
    if (!folderId || !(validIds instanceof Set)) {
        return { removed: 0 };
    }

    const staleIds = game.actors
        .filter((actor) => actor.folder?.id === folderId)
        .filter((actor) => {
            const sourceFlag = actor.flags?.[SOURCE_FLAG_SCOPE] ?? {};
            const actorFolderHint = sourceFlag.folderHint ?? sourceFlag.sourceData?.folder ?? null;
            return actorFolderHint === folderHint && !validIds.has(actor.id);
        })
        .map((actor) => actor.id);

    if (staleIds.length > 0) {
        await Actor.deleteDocuments(staleIds);
    }

    return { removed: staleIds.length };
}

export function register1547ModuleSettings() {
    game.settings.register(MODULE_ID, "maneuverData", {
        name: "Maneuver Data",
        scope: "world",
        config: false,
        type: Object,
        default: []
    });

    game.settings.register(MODULE_ID, "weaponData", {
        name: "Weapon Data",
        scope: "world",
        config: false,
        type: Object,
        default: []
    });

    game.settings.register(MODULE_ID, "armorData", {
        name: "Armor Data",
        scope: "world",
        config: false,
        type: Object,
        default: []
    });

    game.settings.register(MODULE_ID, "ammoData", {
        name: "Ammunition Data",
        scope: "world",
        config: false,
        type: Object,
        default: []
    });

    game.settings.register(MODULE_ID, "monsterData", {
        name: "Monster Data",
        scope: "world",
        config: false,
        type: Object,
        default: []
    });

    game.settings.register(MODULE_ID, "changeSetData", {
        name: "Change Set Data",
        scope: "world",
        config: false,
        type: Object,
        default: []
    });

    game.settings.register(MODULE_ID, "changeData", {
        name: "Change Data",
        scope: "world",
        config: false,
        type: Object,
        default: []
    });

    game.settings.register(MODULE_ID, "requirementData", {
        name: "Requirement Data",
        scope: "world",
        config: false,
        type: Object,
        default: []
    });

    game.settings.register(MODULE_ID, "lastDataSetupAt", {
        name: "Last Data Setup",
        scope: "world",
        config: false,
        type: String,
        default: ""
    });

    game.settings.register(MODULE_ID, "reachMigrationVersion", {
        name: "Reach Migration Version",
        scope: "world",
        config: false,
        type: Number,
        default: 0
    });

    game.settings.register(MODULE_ID, "reactionWindowSeconds", {
        name: "Reaction Window Seconds",
        hint: "How many seconds a reaction window stays open before it automatically passes.",
        scope: "world",
        config: true,
        type: Number,
        range: {
            min: 0,
            max: 30,
            step: 1
        },
        default: 10
    });

    game.settings.register(MODULE_ID, "showSideReadyConfirmation", {
        name: "Show Side Ready Confirmation",
        hint: "Show a confirmation dialog before Side Ready ends the turn for the whole active side.",
        scope: "client",
        config: true,
        type: Boolean,
        default: true
    });

    game.settings.register(MODULE_ID, "boostRollTableUuid", {
        name: "Boost Roll Table UUID",
        hint: "Foundry UUID of the Roll Table used to randomly pick boost ChangeSets when a monster's Boost button is pressed. Example: RollTable.abc1234567890def or worlds/<world>/<id>.",
        scope: "world",
        config: true,
        type: String,
        default: ""
    });

    const moduleSetupFormType = createModuleSetupFormApplicationClass();
    if (moduleSetupFormType) {
        game.settings.registerMenu(MODULE_ID, "moduleSetup", {
            name: "1547 Core Setup",
            label: "Open Setup",
            hint: "Open the 1547 Core setup dialog and load module data into this world.",
            icon: "fas fa-gears",
            type: moduleSetupFormType,
            restricted: true
        });
    } else {
        console.warn(`${MODULE_ID} | Module setup menu unavailable because FormApplication is not defined on this Foundry runtime.`);
    }
}

function createModuleSetupFormApplicationClass() {
    const BaseFormApplication = globalThis.FormApplication;
    if (typeof BaseFormApplication !== "function") {
        return null;
    }

    return class ModuleSetupFormApplication extends BaseFormApplication {
        static get defaultOptions() {
            return foundry.utils.mergeObject(super.defaultOptions, {
                id: `${MODULE_ID}-module-setup`,
                title: "1547 Core Setup",
                template: `${getModuleBasePath()}/templates/module-setup.hbs`,
                width: 520,
                height: "auto",
                closeOnSubmit: false,
                submitOnChange: false,
                submitOnClose: false
            });
        }

        async getData() {
            const storedManeuvers = game.settings.get(MODULE_ID, "maneuverData") ?? [];
            const storedWeapons = game.settings.get(MODULE_ID, "weaponData") ?? [];
            const storedArmors = game.settings.get(MODULE_ID, "armorData") ?? [];
            const storedAmmunition = game.settings.get(MODULE_ID, "ammoData") ?? [];
            const storedMonsters = game.settings.get(MODULE_ID, "monsterData") ?? [];
            const storedChangeSets = game.settings.get(MODULE_ID, "changeSetData") ?? [];
            const storedChanges = game.settings.get(MODULE_ID, "changeData") ?? [];
            const storedRequirements = game.settings.get(MODULE_ID, "requirementData") ?? [];
            const lastDataSetupAt = game.settings.get(MODULE_ID, "lastDataSetupAt") || "";

            return {
                moduleVersion: game.modules.get(MODULE_ID)?.version ?? "unknown",
                storedManeuverCount: Array.isArray(storedManeuvers) ? storedManeuvers.length : 0,
                storedWeaponCount: Array.isArray(storedWeapons) ? storedWeapons.length : 0,
                storedArmorCount: Array.isArray(storedArmors) ? storedArmors.length : 0,
                storedAmmoCount: Array.isArray(storedAmmunition) ? storedAmmunition.length : 0,
                storedMonsterCount: Array.isArray(storedMonsters) ? storedMonsters.length : 0,
                storedChangeSetCount: Array.isArray(storedChangeSets) ? storedChangeSets.length : 0,
                storedChangeCount: Array.isArray(storedChanges) ? storedChanges.length : 0,
                storedRequirementCount: Array.isArray(storedRequirements) ? storedRequirements.length : 0,
                lastDataSetupAt
            };
        }

        activateListeners(html) {
            super.activateListeners(html);

            html.find("[data-action='setup-data']").on("click", async (event) => {
                event.preventDefault();
                await this.#setupData();
            });
        }

        async _updateObject() {
            return;
        }

        async #setupData() {
            try {
                const {
                    maneuvers,
                    weapons,
                    armors,
                    ammunition,
                    monsters,
                    changeSets,
                    changes,
                    requirements
                } = await this.#loadSourceBackedData();

                await this.#importItemsFromData({
                    maneuvers,
                    weapons,
                    armors,
                    ammunition,
                    monsters,
                    changeSets,
                    changes,
                    requirements
                });

                ui.notifications.info(
                    `1547 Core: stored and synced ${maneuvers.length} maneuvers, ${weapons.length} weapons, ${armors.length} armors, ${ammunition.length} ammunition items, ${monsters.length} monsters, ${changeSets.length} change sets, ${changes.length} changes, and ${requirements.length} requirements from source data.`
                );
                this.render(false);
            } catch (error) {
                console.error(`${MODULE_ID} | Failed to setup data`, error);
                ui.notifications.error(`1547 Core: failed to setup data. ${error.message}`);
            }
        }

        async #loadDataset(fileName) {
            const versionTag = encodeURIComponent(game.modules.get(MODULE_ID)?.version ?? Date.now());
            const response = await fetch(`${getModuleBasePath()}/foundry/Templates/${fileName}?v=${versionTag}`, { cache: "no-store" });
            if (!response.ok) {
                throw new Error(`Failed to load ${fileName} (${response.status})`);
            }

            const data = await response.json();
            if (!Array.isArray(data)) {
                throw new Error(`${fileName} did not contain an array.`);
            }

            return data;
        }

        async #loadTemplate(fileName) {
            const versionTag = encodeURIComponent(game.modules.get(MODULE_ID)?.version ?? Date.now());
            const response = await fetch(`${getModuleBasePath()}/foundry/Templates/${fileName}?v=${versionTag}`, { cache: "no-store" });
            if (!response.ok) {
                throw new Error(`Failed to load ${fileName} (${response.status})`);
            }

            return await response.json();
        }

        async #loadSourceBackedData() {
            const [maneuvers, weapons, armors, ammunition, monsters, changeSets, changes, requirements] = await Promise.all([
                this.#loadDataset("maneuvers.json"),
                this.#loadDataset("weapons.json"),
                this.#loadDataset("armors.json"),
                this.#loadDataset("ammunition.json"),
                this.#loadDataset("monsters.json"),
                this.#loadDataset("changesets.json"),
                this.#loadDataset("changes.json"),
                this.#loadDataset("requirements.json")
            ]);

            await Promise.all([
                game.settings.set(MODULE_ID, "maneuverData", maneuvers),
                game.settings.set(MODULE_ID, "weaponData", weapons),
                game.settings.set(MODULE_ID, "armorData", armors),
                game.settings.set(MODULE_ID, "ammoData", ammunition),
                game.settings.set(MODULE_ID, "monsterData", monsters),
                game.settings.set(MODULE_ID, "changeSetData", changeSets),
                game.settings.set(MODULE_ID, "changeData", changes),
                game.settings.set(MODULE_ID, "requirementData", requirements),
                game.settings.set(MODULE_ID, "lastDataSetupAt", new Date().toISOString())
            ]);

            return { maneuvers, weapons, armors, ammunition, monsters, changeSets, changes, requirements };
        }

        /**
         * Move a root-level folder under a new parent. No-op when the
         * folder doesn't exist or is already correctly parented. Used
         * to migrate pre-0.2.4 setups whose kind folders were created
         * at the world root.
         */
        async #reparentRootFolder(folderName, type, newParentId) {
            const folder = game.folders?.find((entry) =>
                entry.type === type
                && entry.name === folderName
                && (entry.folder?.id ?? entry.folder ?? null) === null
            );
            if (!folder || !newParentId || folder.id === newParentId) return;
            await folder.update({ folder: newParentId });
        }

        async #getOrCreateFolder({ folderName, type, parentId = null, color = "#7a7a7a" }) {
            let folder = game.folders?.find((entry) =>
                entry.type === type
                && entry.name === folderName
                && (entry.folder?.id ?? entry.folder ?? null) === parentId
            );
            if (!folder) {
                folder = await Folder.create({
                    name: folderName,
                    type,
                    color,
                    folder: parentId
                });
            }

            return folder;
        }

        async #buildManagedFolderTree() {
            // Top-level namespace folders (one per document collection
            // — Foundry folders are typed and can't cross-parent).
            // Every kind-specific folder below lives inside one of these.
            const coreItemFolder = await this.#getOrCreateFolder({
                folderName: "1547 Core",
                type: "Item",
                color: "#445566"
            });
            const coreActorFolder = await this.#getOrCreateFolder({
                folderName: "1547 Core",
                type: "Actor",
                color: "#445566"
            });

            // Migrate any pre-0.2.4 root-level kind folders into the
            // new core namespace. Idempotent: skips folders already
            // under the right parent or missing entirely.
            await this.#reparentRootFolder("Maneuvers", "Item", coreItemFolder.id);
            await this.#reparentRootFolder("Weapons", "Item", coreItemFolder.id);
            await this.#reparentRootFolder("Armor", "Item", coreItemFolder.id);
            await this.#reparentRootFolder("Ammunition", "Item", coreItemFolder.id);
            await this.#reparentRootFolder("Change Sets", "Item", coreItemFolder.id);
            await this.#reparentRootFolder("Changes", "Item", coreItemFolder.id);
            await this.#reparentRootFolder("Requirements", "Item", coreItemFolder.id);
            await this.#reparentRootFolder("Monsters", "Actor", coreActorFolder.id);

            const monstersFolder = await this.#getOrCreateFolder({ folderName: "Monsters", type: "Actor", parentId: coreActorFolder.id, color: "#516d5b" });
            const maneuverFolder = await this.#getOrCreateFolder({ folderName: "Maneuvers", type: "Item", parentId: coreItemFolder.id });
            const weaponFolder = await this.#getOrCreateFolder({ folderName: "Weapons", type: "Item", parentId: coreItemFolder.id });
            const armorFolder = await this.#getOrCreateFolder({ folderName: "Armor", type: "Item", parentId: coreItemFolder.id });
            const ammoFolder = await this.#getOrCreateFolder({ folderName: "Ammunition", type: "Item", parentId: coreItemFolder.id });
            const changeSetsFolder = await this.#getOrCreateFolder({ folderName: "Change Sets", type: "Item", parentId: coreItemFolder.id, color: "#6d5b51" });
            const changesFolder = await this.#getOrCreateFolder({ folderName: "Changes", type: "Item", parentId: coreItemFolder.id, color: "#6d6551" });
            const requirementsFolder = await this.#getOrCreateFolder({ folderName: "Requirements", type: "Item", parentId: coreItemFolder.id, color: "#5b5b6d" });

            const changeSetGroupFolders = {};
            for (const groupName of CHANGE_SET_GROUPS) {
                changeSetGroupFolders[groupName] = await this.#getOrCreateFolder({
                    folderName: groupName,
                    type: "Item",
                    parentId: changeSetsFolder.id,
                    color: "#6d5b51"
                });
            }

            const changeTypeFolders = {};
            for (const [kind, label] of Object.entries(CHANGE_FOLDER_LABELS)) {
                changeTypeFolders[kind] = await this.#getOrCreateFolder({
                    folderName: label,
                    type: "Item",
                    parentId: changesFolder.id,
                    color: "#6d6551"
                });
            }

            const requirementTypeFolders = {};
            for (const [predicate, label] of Object.entries(REQUIREMENT_FOLDER_LABELS)) {
                requirementTypeFolders[predicate] = await this.#getOrCreateFolder({
                    folderName: label,
                    type: "Item",
                    parentId: requirementsFolder.id,
                    color: "#5b5b6d"
                });
            }

            return {
                coreItemFolder,
                coreActorFolder,
                monstersFolder,
                maneuverFolder,
                weaponFolder,
                armorFolder,
                ammoFolder,
                changeSetsFolder,
                changesFolder,
                requirementsFolder,
                changeSetGroupFolders,
                changeTypeFolders,
                requirementTypeFolders
            };
        }

        async #importItemsFromData({ maneuvers, weapons, armors, ammunition, monsters, changeSets, changes, requirements }) {
            const [actorTemplate, maneuverTemplate, weaponTemplate, armorTemplate, ammoTemplate, powerTemplate, spellTemplate, pactTemplate, recipeTemplate, usageEffectTemplate, changeSetTemplate, changeTemplate, requirementTemplate] = await Promise.all([
                this.#loadTemplate(TEMPLATE_FILES.actorTemplate),
                this.#loadTemplate(TEMPLATE_FILES.maneuver),
                this.#loadTemplate(TEMPLATE_FILES.weapon),
                this.#loadTemplate(TEMPLATE_FILES.armor),
                this.#loadTemplate(TEMPLATE_FILES.ammo),
                this.#loadTemplate(TEMPLATE_FILES.power),
                this.#loadTemplate(TEMPLATE_FILES.spell),
                this.#loadTemplate(TEMPLATE_FILES.pact),
                this.#loadTemplate(TEMPLATE_FILES.recipe),
                this.#loadTemplate(TEMPLATE_FILES.usageEffect),
                this.#loadTemplate(TEMPLATE_FILES.changeSet),
                this.#loadTemplate(TEMPLATE_FILES.change),
                this.#loadTemplate(TEMPLATE_FILES.requirement)
            ]);

            await upsertWorldItems([
                makeTemplateDoc(weaponTemplate),
                makeTemplateDoc(armorTemplate),
                makeTemplateDoc(maneuverTemplate),
                makeTemplateDoc(ammoTemplate),
                makeTemplateDoc(powerTemplate),
                makeTemplateDoc(spellTemplate),
                makeTemplateDoc(pactTemplate),
                makeTemplateDoc(recipeTemplate),
                makeTemplateDoc(usageEffectTemplate),
                makeTemplateDoc(changeSetTemplate),
                makeTemplateDoc(changeTemplate),
                makeTemplateDoc(requirementTemplate)
            ]);

            const folders = await this.#buildManagedFolderTree();

            const maneuverDocs = maneuvers.map((maneuver) =>
                makeItemDoc(normalizeSourceEntry(maneuver, "maneuver"), maneuverTemplate, maneuver.img ?? maneuverTemplate.img ?? "icons/svg/combat.svg", buildManeuverProps, folders.maneuverFolder.id, "Maneuvers")
            );
            const weaponDocs = weapons.map((weapon) =>
                makeItemDoc(normalizeSourceEntry(weapon, "weapon"), weaponTemplate, weapon.img ?? weaponTemplate.img ?? "icons/svg/sword.svg", buildWeaponProps, folders.weaponFolder.id, "Weapons")
            );
            const armorDocs = armors.map((armor) =>
                makeItemDoc(normalizeSourceEntry(armor, "armor"), armorTemplate, armor.img ?? armorTemplate.img ?? "icons/svg/holy-shield.svg", buildArmorProps, folders.armorFolder.id, "Armor")
            );
            const ammoDocs = ammunition.map((ammo) =>
                makeItemDoc(normalizeSourceEntry(ammo, "ammo"), ammoTemplate, ammo.img ?? ammoTemplate.img ?? "icons/svg/item-bag.svg", buildAmmoProps, folders.ammoFolder.id, "Ammunition")
            );
            const changeSetDocs = changeSets.map((changeSet) => {
                const normalized = normalizeSourceEntry(changeSet, "changeset");
                const group = normalized.group ?? normalized.system?.props?.Group ?? "";
                const folder = folders.changeSetGroupFolders[group] ?? folders.changeSetsFolder;
                return makeItemDoc(
                    normalized,
                    changeSetTemplate,
                    normalized.img ?? changeSetTemplate.img ?? "icons/svg/item-bag.svg",
                    buildChangeSetProps,
                    folder.id,
                    group || "Change Sets"
                );
            });
            const changeDocs = changes.map((change) => {
                const normalized = normalizeSourceEntry(change, "change");
                const kind = normalized.kind ?? normalized.system?.props?.Kind ?? "";
                const folder = folders.changeTypeFolders[kind] ?? folders.changesFolder;
                return makeItemDoc(
                    normalized,
                    changeTemplate,
                    normalized.img ?? changeTemplate.img ?? "icons/svg/item-bag.svg",
                    buildChangeProps,
                    folder.id,
                    CHANGE_FOLDER_LABELS[kind] ?? "Changes"
                );
            });
            const requirementDocs = requirements.map((requirement) => {
                const normalized = normalizeSourceEntry(requirement, "requirement");
                const predicate = normalized.predicateType ?? normalized.system?.props?.PredicateType ?? "";
                const folder = folders.requirementTypeFolders[predicate] ?? folders.requirementsFolder;
                return makeItemDoc(
                    normalized,
                    requirementTemplate,
                    normalized.img ?? requirementTemplate.img ?? "icons/svg/item-bag.svg",
                    buildRequirementProps,
                    folder.id,
                    REQUIREMENT_FOLDER_LABELS[predicate] ?? "Requirements"
                );
            });
            const monsterDocs = monsters.map((monster) =>
                makeActorDoc(normalizeSourceEntry(monster, "monster", "Actor"), folders.monstersFolder.id, "Monsters")
            );

            await pruneManagedFolderItems({
                folderId: folders.maneuverFolder.id,
                validIds: new Set(maneuverDocs.map((doc) => doc._id)),
                templateId: maneuverTemplate._id,
                folderHint: "Maneuvers"
            });
            await pruneManagedFolderItems({
                folderId: folders.weaponFolder.id,
                validIds: new Set(weaponDocs.map((doc) => doc._id)),
                templateId: weaponTemplate._id,
                folderHint: "Weapons"
            });
            await pruneManagedFolderItems({
                folderId: folders.armorFolder.id,
                validIds: new Set(armorDocs.map((doc) => doc._id)),
                templateId: armorTemplate._id,
                folderHint: "Armor"
            });
            await pruneManagedFolderItems({
                folderId: folders.ammoFolder.id,
                validIds: new Set(ammoDocs.map((doc) => doc._id)),
                templateId: ammoTemplate._id,
                folderHint: "Ammunition"
            });
            for (const groupName of CHANGE_SET_GROUPS) {
                const folder = folders.changeSetGroupFolders[groupName];
                await pruneManagedFolderItems({
                    folderId: folder.id,
                    validIds: new Set(changeSetDocs.filter((doc) => doc.folder === folder.id).map((doc) => doc._id)),
                    templateId: changeSetTemplate._id,
                    folderHint: groupName
                });
            }
            await pruneManagedFolderItems({
                folderId: folders.changeSetsFolder.id,
                validIds: new Set(changeSetDocs.filter((doc) => doc.folder === folders.changeSetsFolder.id).map((doc) => doc._id)),
                templateId: changeSetTemplate._id,
                folderHint: "Change Sets"
            });
            for (const [kind, label] of Object.entries(CHANGE_FOLDER_LABELS)) {
                const folder = folders.changeTypeFolders[kind];
                await pruneManagedFolderItems({
                    folderId: folder.id,
                    validIds: new Set(changeDocs.filter((doc) => doc.folder === folder.id).map((doc) => doc._id)),
                    templateId: changeTemplate._id,
                    folderHint: label
                });
            }
            await pruneManagedFolderItems({
                folderId: folders.changesFolder.id,
                validIds: new Set(changeDocs.filter((doc) => doc.folder === folders.changesFolder.id).map((doc) => doc._id)),
                templateId: changeTemplate._id,
                folderHint: "Changes"
            });
            for (const [predicate, label] of Object.entries(REQUIREMENT_FOLDER_LABELS)) {
                const folder = folders.requirementTypeFolders[predicate];
                await pruneManagedFolderItems({
                    folderId: folder.id,
                    validIds: new Set(requirementDocs.filter((doc) => doc.folder === folder.id).map((doc) => doc._id)),
                    templateId: requirementTemplate._id,
                    folderHint: label
                });
            }
            await pruneManagedFolderItems({
                folderId: folders.requirementsFolder.id,
                validIds: new Set(requirementDocs.filter((doc) => doc.folder === folders.requirementsFolder.id).map((doc) => doc._id)),
                templateId: requirementTemplate._id,
                folderHint: "Requirements"
            });
            await pruneManagedFolderActors({
                folderId: folders.monstersFolder.id,
                validIds: new Set(monsterDocs.map((doc) => doc._id)),
                folderHint: "Monsters"
            });

            const docs = [
                ...maneuverDocs,
                ...weaponDocs,
                ...armorDocs,
                ...ammoDocs,
                ...changeSetDocs,
                ...changeDocs,
                ...requirementDocs
            ];
            const [itemResult, actorResult] = await Promise.all([
                upsertWorldItems(docs),
                upsertWorldActors([
                    makeActorDoc(actorTemplate, null, "Actor Template"),
                    ...monsterDocs
                ])
            ]);

            return {
                totalItems: docs.length,
                totalActors: monsterDocs.length,
                createdItems: itemResult.created,
                updatedItems: itemResult.updated,
                createdActors: actorResult.created,
                updatedActors: actorResult.updated
            };
        }
    };
}
